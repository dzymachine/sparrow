---
id: timeline-and-costs
title: How long it takes and what it costs
applies_if: always
sources: [S9, S11, S12, S20]
verify: true
---

# Timeline and costs

## Plain English
Even if you and your spouse agree on everything, a California divorce cannot be final in less than six months and one day after your spouse is served. If you disagree, it usually takes much longer.

## Facts
- Minimum: six months and one day from service; cannot be shortened [S11].
- Contested cases average 12 to 24 months; complex cases longer [S11; verify].
- Spouse has 30 days to respond after being served [S20].
- Residency: 6 months in California, 3 months in the county [S12].
- Filing fee: $435 as of January 2026 [S12; verify on courts.ca.gov].
- Fee waiver forms if you can't afford fees: FW-001 and FW-003 [S9].

## Agent notes
Present timelines as estimates. County practice varies.
