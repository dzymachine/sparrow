---
id: context-and-statistics
title: Background statistics (for pitch and education content, not legal advice)
applies_if: always
sources: [S14, S15, S16, S17, S22, S23, S24]
verify: true
---

# Context and statistics

Use for education content and the pitch. Do not present these as predictions about the user.

- Women's family income dropped 46 to 50% after divorce in a University of Michigan study of U.S. Baby Boomers, nearly double the drop for men; Black women had the highest economic precarity [S15].
- A 2012 GAO report, as cited by NextTribe, found a 41% drop in household income for women over 50 who divorce, versus 23% for men [S23; secondary, verify against GAO].
- Husbands are the primary breadwinner in 55% of U.S. marriages; 29% earn about the same; wives earn more in 16% [S14]. In 2022 the median income was about $35,000 for wives and $65,000 for husbands [S14].
- About 200,000 divorce petitions are filed in California each year; about 70% involve at least one self-represented person at the start and about 80% by judgment [S16; 2010 figure].
- Low-income Americans receive inadequate or no legal help for about 92% of their civil legal problems (all civil matters, not only divorce) [S17]. LSC's 2017 study put it at 86% [S24].
- 28% of respondents in one survey stayed in a relationship longer than they wanted for financial reasons [S22; surveyor unclear, indicative only].
