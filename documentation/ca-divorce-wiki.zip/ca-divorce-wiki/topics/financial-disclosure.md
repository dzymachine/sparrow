---
id: financial-disclosure
title: Sharing the money picture (financial disclosures)
applies_if: always
forms: [FL-140, FL-142, FL-150, FL-141]
sources: [S6, S7, S8, S21]
verify: true
---

# Financial disclosures

## Plain English
Both you and your spouse have to show each other your income, what you own and what you owe. This is required, and it is one of the places the law works in your favor: your spouse has to disclose too.

## What it involves
- FL-140 (cover form), FL-142 (assets and debts) and FL-150 (income and expenses) are served on your spouse. FL-140 and FL-142 are not filed with the court [S7].
- FL-150 needs proof of your income from the past two months attached [S8].
- Then FL-141 tells the court disclosures were served [S7].
- Timing: at the same time as filing or within 60 days [S6]. The 60 days can be changed by written agreement or court order [S21].

## Why it matters for our users
If she was kept out of the accounts, she cannot list what she doesn't know exists. The document reader helps by finding accounts and income in tax returns, W-2s and statements, and by flagging possible gaps (for example, interest income with no matching account) for her to ask about or request.

## Agent notes
- Phrase gaps as questions to ask, never accusations.
- Suggest adding missing items to the lawyer brief.
