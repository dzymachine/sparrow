---
id: attorney-fees
title: Asking your spouse to help pay for your lawyer
applies_if: income_self < income_spouse
forms: [FL-300, FL-319, FL-150, FL-158]
legal_basis: Family Code sections 2030 and 2032; Rule of Court 5.427
sources: [S2, S3, S4, S5, S13]
verify: false
---

# Attorney fees based on need

## Plain English
If your spouse earns much more, they may be able to afford a lawyer while you can't. The law lets you ask the judge to make your spouse pay some or all of your legal costs, so both sides have fair access to legal help.

## Facts
- Family Code section 2030: if the court finds a disparity in access to legal help and that one party is able to pay for both, it shall order attorney's fees and costs [S5].
- The FL-319 form asks you to show the other party has, or is reasonably likely to have, the ability to pay for both sides [S4].
- How to ask (Rule 5.427): Request for Order (FL-300), Request for Attorney's Fees and Costs Attachment (FL-319) or comparable declaration, a current FL-150, and a personal declaration (FL-158 or comparable) [S3].
- Missing paperwork matters: a fee motion was denied in one appeal with the note that form 319 was not filed [S13].
- Official how-to page: [S2].

## Card text
"You may be able to ask your spouse to help pay for your lawyer. Because you earn less, the court can order them to contribute so you both have fair access to legal help. You'll need 4 forms."

## Agent notes
Not automatic. She must show need and the spouse's ability to pay. The judge decides.
