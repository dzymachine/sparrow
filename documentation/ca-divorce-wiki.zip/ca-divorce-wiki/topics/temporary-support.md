---
id: temporary-support
title: Temporary spousal support (help with bills while the case is open)
applies_if: income_self < income_spouse
forms: [FL-300, FL-150]
legal_basis: Family Code section 3600
sources: [S1, S10, S18, S19]
verify: true
---

# Temporary spousal support

## Plain English
A divorce can take six months or much longer, and bills don't wait. You can ask the judge to order your spouse to help with your living costs while the case is open. The judge looks at how much you need and how much your spouse can afford.

## Facts
- You can ask as soon as the case is filed [S1].
- Legal basis: Family Code section 3600. The court may order the amount necessary based on need and ability to pay [S19].
- How to ask: Request for Order (FL-300) with an Income and Expense Declaration (FL-150) [S10]. Filing fee unless waived [S10].
- Orders are made without a full trial and rely on the FL-150 disclosures [S19].
- Amount: many counties use a guideline formula; one law-firm guide describes the Santa Clara guideline as 40% of the higher earner's net income minus 50% of the lower earner's net income [S18; verify, varies by county]. Do not quote this as a promise.
- It is temporary. Long-term support after the divorce is decided separately using the factors in Family Code section 4320 [S18].

## Card text
"You may be able to ask for help paying bills while your divorce is in progress. Because you earn less than your spouse, the court can order them to help with your living costs. We'll show you which forms."

## Agent notes
The judge decides. Never give an expected amount.
