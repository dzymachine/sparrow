# California Divorce Knowledge Wiki (for the guide agent)

Purpose: ground the agent's answers for women in California who are considering or going through a divorce. The agent should retrieve from these files, cite source IDs (S1, S2, ...), and never state a legal rule that is not in the wiki.

## Status: HACKATHON DRAFT. NOT LEGAL ADVICE.
Compiled on 2026-11-13 from court self-help pages, county court packets, California Rules of Court, and some law-firm and news sources. Items marked `verify: true` came from secondary sources or are older. Before real use, have a California family law attorney or a court self-help center review every file, and confirm form numbers, fees and deadlines on courts.ca.gov.

## How to use
1. Read `agent-guidelines.md` first. These are behavior rules for the agent.
2. `rules.json` maps a user profile to personalized "rights" and "forms" cards. The rules engine decides WHAT to show; the model only explains it in plain English. This keeps the model from inventing legal claims.
3. `topics/*.md` hold the plain-English explanations and legal basis. Each has front matter (id, applies_if, forms, sources, verify).
4. `sources.md` lists every source by ID. Always cite by ID.
5. `demo-persona.json` is the fake user for the demo (Maria). Use fake documents on stage; do not upload real ones.

## Files
- agent-guidelines.md
- rules.json
- sources.md
- demo-persona.json
- topics/process-overview.md
- topics/forms.md
- topics/financial-disclosure.md
- topics/temporary-support.md
- topics/attorney-fees.md
- topics/timeline-and-costs.md
- topics/context-and-statistics.md

## Profile fields the rules use
income_self (monthly, number), income_spouse (monthly, number), has_children (bool), years_married (number), has_access_to_accounts (bool), owns_home (bool), case_filed (bool), stage (one of: thinking, preparing, filing, waiting, final).
