# Sources (cite by ID)

Reliability: A = court or official rule, B = county court packet or published research, C = law-firm, news or secondary site (verify before relying).

| ID | Rel. | Source | URL |
|---|---|---|---|
| S1 | A | California Courts Self-Help: Ask for temporary spousal support | https://selfhelp.courts.ca.gov/ask-temporary-spousal-support |
| S2 | A | California Courts Self-Help: Ask for money to hire a lawyer | https://selfhelp.courts.ca.gov/request-attorney-fees |
| S3 | A | California Rules of Court, rule 5.427 (attorney's fees and costs) | https://www.courts.ca.gov/cms/rules/index/five/rule5_427 |
| S4 | A | Form FL-319, Request for Attorney's Fees and Costs Attachment | https://www4.courts.ca.gov/documents/fl319.pdf |
| S5 | B | Family Code section 2030 (text) | https://california.public.law/codes/family_code_section_2030 |
| S6 | B | San Mateo Superior Court: Divorce and Legal Separation | https://sanmateo.courts.ca.gov/self-help/divorce-legal-separation |
| S7 | B | Contra Costa Superior Court: Divorce Roadmap | https://contracosta.courts.ca.gov/divisions/family-and-children/divorce-legal-separation-annulment/divorce-roadmap |
| S8 | B | Inyo Superior Court: Divorce Forms and Filing | https://www.inyo.courts.ca.gov/divorce-forms-filing |
| S9 | B | San Luis Obispo Superior Court: Start a Divorce Case | https://www.slo.courts.ca.gov/self-help/family-law/divorce/start-divorce-case |
| S10 | B | Contra Costa Superior Court: Request for Order packet | https://contracosta.courts.ca.gov/system/files/forms-filing/famlaw006-requestfororderpacket-1.pdf |
| S11 | C | Divorce.law: California divorce timeline | https://divorce.law/guides/divorce-timeline-california |
| S12 | C | Divorce.law: California divorce recovery timeline and filing fee | https://divorce.law/guides/divorce-recovery-timeline/california/ |
| S13 | B | Sharples v. Sharples, 223 Cal. App. 4th 160 (2014) | https://hallapproved.com/ca/cases/appeals/2014/2650533/ |
| S14 | B | Pew Research Center (April 2023), breadwinner wives | https://www.pewresearch.org/social-trends/2023/04/13/in-a-growing-share-of-u-s-marriages-husbands-and-wives-earn-about-the-same/ |
| S15 | B | University of Michigan Population Studies Center (July 2025) | https://psc.isr.umich.edu/news/research-shows-economic-consequences-of-divorce-in-the-us-vary-by-gender-race-and-ethnicity/ |
| S16 | B | California Law Review (Hough, 2010): self-represented litigants | https://californialawreview.org/online/self-represented-litigants-in-family-law |
| S17 | C | Bloomberg Law: civil legal help gap | https://news.bloomberglaw.com/us-law-week/legal-help-for-civil-matters-shouldnt-be-reserved-for-the-rich |
| S18 | C | Divorce.law: California spousal support guide | https://divorce.law/guides/alimony-spousal-support/california/ |
| S19 | C | Divorce.law: temporary alimony in California | https://divorce.law/guides/temporary-alimony-during-divorce/california/ |
| S20 | B | Tulare Superior Court: divorce packet (summons gives 30 days) | https://www.tulare.courts.ca.gov/system/files/forms-and-filings/disso-packet-7125-part-1.pdf |
| S21 | A | FL-107-INFO, Legal Steps for a Divorce (Judicial Council) | https://courts.ca.gov/sites/default/files/courts/default/2024-11/fl107info.pdf |
| S22 | C | Fox 5 DC: financial-reasons survey coverage | https://www.fox5dc.com/news/americans-would-marry-money-current-economy-survey |
| S23 | C | NextTribe: financial inequality after divorce | https://nexttribe.com/magazine/financial-inequality-after-divorce/ |
| S24 | B | Legal Services Corporation: The Justice Gap (2017 summary) | https://www.lsc.gov/sites/default/files/images/TheJusticeGap-ExecutiveSummary.pdf |
