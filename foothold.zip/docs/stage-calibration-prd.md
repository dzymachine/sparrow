# PRD: Private Stage Calibration Flow ("Calibrate My Stage")

## 1. Overview & Purpose
Newly separated or contemplating women arrive at vastly different emotional and administrative starting points—from quietly researching in secret to finalizing a decree or rebuilding solo. Asking for bank logins or showing a 40-item checklist upfront creates anxiety and drop-off.

The **Stage Calibration** feature is a lightweight, 3-step private intake modal that calibrates the workspace, task prioritization, financial jargon level, and Journey Guide responses around the user's real-world situation in under 45 seconds.

## 2. Entry Points & UX Principles
- **Non-Blocking Launch:** Users land directly inside a populated workspace so they can explore immediately without forced onboarding walls.
- **Entry Triggers:**
  1. Sidebar CTA: **Calibrate My Stage**
  2. Overview Hero CTA: **Update My Stage**
  3. Footer link: **Adjust stage or reset sample data**
- **Safety & Trust Rules:**
  - Zero bank logins, SSNs, or sensitive PII requested.
  - Explicit reassurance on Step 1: *"Nothing is shared externally."*
  - Instant **Reset Sample Data** control available inside the modal footer alongside **Back**, **Continue**, and **Save My Preferences**.

---

## 3. Complete List of Questions & Answer Choices

### Step 1 of 3 — Journey Phase (Single-Select, Required)
- **Question:** `1. Where are you in your separation journey right now?`
- **Helper Copy:** `This prioritizes your Next 3 Moves and overview guidance. Nothing is shared externally.`
- **Stored Field:** `stage: JourneyStage`

| Answer Option (Phase & Label) | Sub-Copy Shown to User | Reassurance Copy (Shown on Overview) | Value Key |
| :--- | :--- | :--- | :--- |
| **Phase 01: Quiet Contemplation** | Explore what solo life could cost, privately and without pressure. | You do not need to link any bank accounts or make decisions today. Start with rough numbers and clear facts. | `considering` |
| **Phase 02: Quiet Preparation** | Get visibility into household accounts before anything changes. | Focus on gathering copies of key documents, checking your own credit, and establishing a private solo account. | `preparing` |
| **Phase 03: Active Separation** | Keep day-to-day cash steady while testing settlement tradeoffs. | Separate temporary transition costs from your long-term monthly baseline so you can evaluate proposals clearly. | `separating` |
| **Phase 04: Finalizing & Untangling** | Work through joint accounts, QDROs, and beneficiary updates step by step. | Take these administrative steps one at a time. Mark items as waiting whenever the ball is in someone else's court. | `finalizing` |
| **Phase 05: Solo Stabilization** | Build your solo peace-of-mind cushion and grow on your own terms. | Your baseline is yours. Focus on steady monthly breathing room and simple, automated savings. | `rebuilding` |

---

### Step 2 of 3 — Immediate Priorities (Multi-Select, Optional)
- **Question:** `2. What feels most urgent for you this week?`
- **Helper Copy:** `Choose as many as apply. You can change these anytime.`
- **Stored Field:** `urgentFocus: string[]`

| # | Answer Option |
| :-: | :--- |
| 1 | `See what I can afford solo` |
| 2 | `Untangle joint accounts` |
| 3 | `Gather statements privately` |
| 4 | `Compare keeping the house vs. renting` |
| 5 | `Track shared child expenses` |
| 6 | `Start building my own credit & savings` |

---

### Step 3 of 3 — Financial Comfort & Tone (Single-Select, Required)
- **Question:** `3. How comfortable do you feel with financial terms?`
- **Helper Copy:** `No judgment—half of our members are managing solo accounts for the very first time.`
- **Stored Field:** `comfortLevel: ComfortLevel`

| Answer Title | Supporting Description | Value Key |
| :--- | :--- | :--- |
| **Explain everything in plain English** | I rarely handled household finances and want clear, jargon-free context. | `beginner` |
| **I know the basics, just need a map** | I manage day-to-day bills, but divorce splits, QDROs, and taxes feel overwhelming. | `basics` |
| **Comfortable with numbers, need structure** | I want an organized tracker and scenario tools without extra hand-holding. | `comfortable` |

---

## 4. Downstream System Behavior

1. **Overview Hero & Reassurance Messaging (`stage`):**
   - Updates the phase indicator, headline, and calm reassurance guidance at the top of the workspace.
2. **Dynamic "Your Next 3 Moves" Prioritization (`stage`):**
   - Sorts all incomplete (`todo` / `waiting`) roadmap tasks by proximity to the selected `stage` first, then by `priorityOrder`, surfacing only the 3 most relevant actions.
3. **Roadmap Default Context (`stage`):**
   - Pre-selects the user's active phase when creating custom personal tasks.
4. **Journey Guide AI Context (`stage`, `comfortLevel`, `urgentFocus`):**
   - Passes the calibrated stage and financial comfort level in every `/api/guide-chat` request so the chatbot adapts explanation depth and suggests navigation pointers matched to her phase.
5. **State Persistence & Reset:**
   - Saved automatically to browser storage (`localStorage`) so calibrations persist across sessions without requiring an account login.
   - Clicking **Reset Sample Data** restores all defaults and clears custom local edits.

---

## 5. UI, Accessibility & Acceptance Criteria
- **Modal Controls:**
  - Header displays `Step {1|2|3} of 3 · Private Calibration` and an accessible Close (`X`) button.
  - Footer pins **Reset Sample Data** on the left and step navigation (**Back** / **Continue** / **Save My Preferences**) on the right.
- **Accessibility:**
  - `role="dialog"` and `aria-modal="true"` with `aria-labelledby` pointing to the modal title.
  - Keyboard-accessible selection buttons with clear selected vs. unselected border/fill states (Step 1 pairs border contrast with explicit `Selected` text).
- **Acceptance Criteria:**
  - User can move freely between Steps 1, 2, and 3 without losing selections made in earlier steps.
  - Closing via `X` discards unsaved modal edits; clicking **Save My Preferences** updates workspace state immediately and closes the modal.
  - Mobile viewports (`< 640px`) scroll comfortably within `max-h-[70vh]` without clipping footer action buttons.

---

## 6. Success Metrics (KPIs)
- **Calibration Completion Rate:** Percentage of users who open the modal and reach **Save My Preferences** (Target: >= 80%).
- **Stage Distribution Mix:** Breakdown of users across Phases 01–05 to inform content and script prioritization.
- **Post-Calibration Action Rate:** Percentage of users who click a **Next 3 Moves** item or **Journey Guide** pointer within 2 minutes of saving calibration.
