import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ChatTurn {
  role: 'user' | 'model';
  text: string;
}

interface WorkspaceContext {
  stage: string;
  stageLabel: string;
  activeTab: string;
  comfortLevel: string;
  doneTasks: number;
  totalTasks: number;
  unknownAccounts: number;
  sharedAccounts: number;
  breathingRoom: number;
}

const SYSTEM_INSTRUCTION = `You are the Foothold Journey Guide, a calm, empathetic, practical financial navigation assistant for women who are contemplating, going through, or rebuilding after a separation or divorce.

Tone & Boundaries:
- Warm, steady, clear, and zero-shame. Avoid Wall Street jargon unless you immediately explain it in plain English.
- Keep responses concise (2-4 short paragraphs or crisp bullet points max) so the user never feels overwhelmed.
- Clarify briefly when relevant that you provide organizational and educational guidance, not formal legal or tax advice.
- Never ask for sensitive credentials or bank logins. Remind users that Foothold works privately without bank linking.

Website Map (use exact section IDs in suggestedNav when pointing the user where to go):
1. "overview" ("Where I Stand"): Shows her current phase summary, 4 baseline numbers, Next 3 Moves, and plain-English glossary decoder.
2. "roadmap" ("Step-by-Step Roadmap"): Full 5-phase checklist (Contemplating, Quiet Prep, Separating, Untangling, Rebuilding) with copy-paste phone/email scripts, "Waiting on someone else" toggles, and custom steps.
3. "vault" ("Account Vault"): Private inventory of shared vs. solo accounts, debts, and policies—including "Unknown (Discovery List)" items for accounts her spouse controls, plus CSV export for attorneys/mediators.
4. "clarity" ("Clarity & Sandbox"): "My New Baseline" (separates steady monthly income from one-time settlement/transitional cash, 3-bucket expenses, 1/3/6-month cushion targets) and "Can I Afford This? Sandbox" (Keep Marital Home vs. Rent/Downsize sliders, plus Work & Childcare net-gain check).
5. "protection" ("Ledger & Protection"): Neutral Co-Parenting Split Expense Ledger (with CSV export) and post-decree Beneficiary & Benefits Reset Checklist (401k, life insurance, health coverage 60-day window, healthcare proxy).

Always include 1-2 relevant suggestedNav pointers when a specific area of the app helps answer her question.`;

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.post('/api/guide-chat', async (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(503).json({
        error:
          'The Journey Guide service is not configured yet. Please check your GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const body = req.body as {
      messages?: ChatTurn[];
      context?: WorkspaceContext;
    };

    const messages = Array.isArray(body?.messages) ? body.messages : [];
    const ctx = body?.context;

    if (messages.length === 0) {
      res.status(400).json({ error: 'Please enter a question to ask the Journey Guide.' });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const contextSummary = ctx
      ? `Current user workspace state:
- Journey Phase: ${ctx.stageLabel} (${ctx.stage})
- Currently viewing section: ${ctx.activeTab}
- Financial comfort level: ${ctx.comfortLevel}
- Roadmap progress: ${ctx.doneTasks} of ${ctx.totalTasks} steps completed
- Account Vault: ${ctx.sharedAccounts} still-shared accounts, ${ctx.unknownAccounts} unknown-balance discovery items
- Steady monthly breathing room: $${Math.round(ctx.breathingRoom)}`
      : '';

    const contents = messages.map((m, idx) => {
      const isLastUser = idx === messages.length - 1 && m.role === 'user';
      const text =
        isLastUser && contextSummary
          ? `[Workspace Context]\n${contextSummary}\n\n[User Question]\n${m.text}`
          : m.text;
      return {
        role: m.role === 'model' ? 'model' : 'user',
        parts: [{ text }],
      };
    });

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: {
                type: Type.STRING,
                description:
                  'Calm, helpful, plain-English guidance answering the user question with context-aware steps.',
              },
              suggestedNav: {
                type: Type.ARRAY,
                description:
                  'Up to 2 relevant Foothold website sections the user can jump to next.',
                items: {
                  type: Type.OBJECT,
                  properties: {
                    section: {
                      type: Type.STRING,
                      description:
                        'One of: overview, roadmap, vault, clarity, protection',
                    },
                    label: {
                      type: Type.STRING,
                      description:
                        'Short action label like "Open Account Vault" or "Test Housing Sandbox"',
                    },
                    reason: {
                      type: Type.STRING,
                      description: 'One short phrase explaining what to do there.',
                    },
                  },
                  required: ['section', 'label', 'reason'],
                },
              },
            },
            required: ['reply', 'suggestedNav'],
          },
        },
      });

      const raw = (response.text ?? '').trim();
      const parsed = JSON.parse(raw) as {
        reply?: string;
        suggestedNav?: { section: string; label: string; reason: string }[];
      };

      const validSections = new Set([
        'overview',
        'roadmap',
        'vault',
        'clarity',
        'protection',
      ]);

      const safeNav = Array.isArray(parsed.suggestedNav)
        ? parsed.suggestedNav
            .filter((item) => validSections.has(item.section))
            .slice(0, 2)
        : [];

      res.json({
        reply:
          parsed.reply ||
          'I am here to help you take this one step at a time. Let me know what feels most pressing right now.',
        suggestedNav: safeNav,
      });
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Unable to reach the Journey Guide right now.';
      res.status(500).json({
        error: `Could not generate a response right now (${msg}). Please try again.`,
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Foothold server running on http://0.0.0.0:${port}`);
  });
}

startServer();
