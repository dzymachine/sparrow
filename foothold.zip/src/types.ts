export type JourneyStage =
  | 'considering'
  | 'preparing'
  | 'separating'
  | 'finalizing'
  | 'rebuilding';

export type ComfortLevel = 'beginner' | 'basics' | 'comfortable';

export type TaskStatus = 'todo' | 'waiting' | 'done';

export interface RoadmapTask {
  id: string;
  stage: JourneyStage;
  title: string;
  duration: string;
  whyItMatters: string;
  steps: string[];
  scriptTitle?: string;
  scriptBody?: string;
  status: TaskStatus;
  priorityOrder: number;
  isCustom?: boolean;
}

export type AccountType =
  | 'Checking'
  | 'Savings'
  | 'Credit Card'
  | 'Mortgage / Lease'
  | 'Retirement'
  | 'Insurance'
  | 'Utility / Bill';

export type AccountStatus = 'shared' | 'in_progress' | 'solo' | 'unknown';

export interface AccountItem {
  id: string;
  name: string;
  institution: string;
  type: AccountType;
  balance: number | null; // null means unknown / needs discovery
  isDebt: boolean;
  status: AccountStatus;
  checks: {
    myNameOnly: boolean;
    exRemoved: boolean;
    autopayMoved: boolean;
    passwordUpdated: boolean;
  };
  notes: string;
}

export interface BudgetState {
  // Steady Monthly Income
  netPaycheck: number;
  reliableSupport: number;
  otherSteadyIncome: number;
  // Transitional / One-Time Pool
  soloCashAvailable: number;
  expectedSettlementCash: number;
  // 3-Bucket Monthly Outflows
  mustPays: {
    housing: number;
    utilities: number;
    groceries: number;
    childcare: number;
    minimumDebt: number;
    insurance: number;
  };
  lifeAndKids: {
    schoolAndActivities: number;
    medicalCopays: number;
    transportation: number;
    personalEssentials: number;
  };
  cushionGoalMonthly: number;
}

export interface SplitExpense {
  id: string;
  date: string;
  description: string;
  category: 'Medical' | 'School' | 'Activities' | 'Childcare' | 'Other';
  totalAmount: number;
  mySharePercent: number;
  paidByMe: boolean;
  status: 'logged' | 'requested' | 'reimbursed';
  note: string;
}

export interface BeneficiaryItem {
  id: string;
  accountName: string;
  category: 'Retirement' | 'Insurance' | 'Banking' | 'Legal & Estate';
  currentStatus: 'needs_update' | 'in_progress' | 'updated';
  guidance: string;
}

export type NavSection =
  | 'overview'
  | 'roadmap'
  | 'vault'
  | 'clarity'
  | 'protection';

export interface AppState {
  stage: JourneyStage;
  comfortLevel: ComfortLevel;
  urgentFocus: string[];
  tasks: RoadmapTask[];
  accounts: AccountItem[];
  budget: BudgetState;
  splitExpenses: SplitExpense[];
  beneficiaries: BeneficiaryItem[];
}
