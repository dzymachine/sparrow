import { useEffect, useState } from 'react';
import {
  Compass,
  ListChecks,
  FolderLock,
  SlidersHorizontal,
  ShieldCheck,
  EyeOff,
  Menu,
  X,
} from 'lucide-react';
import {
  AccountItem,
  AppState,
  BeneficiaryItem,
  BudgetState,
  ComfortLevel,
  JourneyStage,
  NavSection,
  SplitExpense,
  TaskStatus,
} from './types';
import { INITIAL_STATE, STAGE_META } from './data/initialData';
import { DiscreetCover } from './components/DiscreetCover';
import { IntakeModal } from './components/IntakeModal';
import { OverviewView } from './components/OverviewView';
import { RoadmapView } from './components/RoadmapView';
import { VaultView } from './components/VaultView';
import { ClaritySandboxView } from './components/ClaritySandboxView';
import { ProtectionLedgerView } from './components/ProtectionLedgerView';
import { JourneyGuideChat } from './components/JourneyGuideChat';

const STORAGE_KEY = 'foothold_mvp_state_v1';

const NAV_ITEMS: { id: NavSection; label: string; icon: typeof Compass }[] = [
  { id: 'overview', label: 'Where I Stand', icon: Compass },
  { id: 'roadmap', label: 'Step-by-Step Roadmap', icon: ListChecks },
  { id: 'vault', label: 'Account Vault', icon: FolderLock },
  { id: 'clarity', label: 'Clarity & Sandbox', icon: SlidersHorizontal },
  { id: 'protection', label: 'Ledger & Protection', icon: ShieldCheck },
];

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved) as AppState;
      }
    } catch {
      // Fall back to initial state
    }
    return INITIAL_STATE;
  });

  const [activeTab, setActiveTab] = useState<NavSection>('overview');
  const [discreetMode, setDiscreetMode] = useState(false);
  const [showIntake, setShowIntake] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage quota errors
    }
  }, [state]);

  if (discreetMode) {
    return <DiscreetCover onReturn={() => setDiscreetMode(false)} />;
  }

  const currentStageMeta = STAGE_META[state.stage];
  const currentNavLabel =
    NAV_ITEMS.find((n) => n.id === activeTab)?.label ?? 'Workspace';

  const handleUpdateTaskStatus = (taskId: string, status: TaskStatus) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => (t.id === taskId ? { ...t, status } : t)),
    }));
  };

  const handleAddTask = (
    title: string,
    stage: JourneyStage,
    duration: string,
    whyItMatters: string
  ) => {
    const newTask = {
      id: `custom-${Date.now()}`,
      stage,
      title,
      duration,
      whyItMatters,
      steps: ['Complete this personal step and mark it done when finished.'],
      status: 'todo' as TaskStatus,
      priorityOrder: 99,
      isCustom: true,
    };
    setState((prev) => ({ ...prev, tasks: [newTask, ...prev.tasks] }));
  };

  const handleUpdateAccount = (updated: AccountItem) => {
    setState((prev) => ({
      ...prev,
      accounts: prev.accounts.map((a) => (a.id === updated.id ? updated : a)),
    }));
  };

  const handleAddAccount = (account: Omit<AccountItem, 'id'>) => {
    const created: AccountItem = {
      ...account,
      id: `acc-${Date.now()}`,
    };
    setState((prev) => ({ ...prev, accounts: [created, ...prev.accounts] }));
  };

  const handleBudgetChange = (nextBudget: BudgetState) => {
    setState((prev) => ({ ...prev, budget: nextBudget }));
  };

  const handleAddExpense = (item: Omit<SplitExpense, 'id'>) => {
    const created: SplitExpense = {
      ...item,
      id: `exp-${Date.now()}`,
    };
    setState((prev) => ({
      ...prev,
      splitExpenses: [created, ...prev.splitExpenses],
    }));
  };

  const handleUpdateExpenseStatus = (
    id: string,
    status: SplitExpense['status']
  ) => {
    setState((prev) => ({
      ...prev,
      splitExpenses: prev.splitExpenses.map((e) =>
        e.id === id ? { ...e, status } : e
      ),
    }));
  };

  const handleUpdateBeneficiary = (
    id: string,
    currentStatus: BeneficiaryItem['currentStatus']
  ) => {
    setState((prev) => ({
      ...prev,
      beneficiaries: prev.beneficiaries.map((b) =>
        b.id === id ? { ...b, currentStatus } : b
      ),
    }));
  };

  const handleSaveIntake = (
    stage: JourneyStage,
    comfortLevel: ComfortLevel,
    urgentFocus: string[]
  ) => {
    setState((prev) => ({
      ...prev,
      stage,
      comfortLevel,
      urgentFocus,
    }));
  };

  const handleResetDemo = () => {
    setState(INITIAL_STATE);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore
    }
  };

  const navigateTo = (tab: NavSection) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-earth-50 text-earth-900 flex">
      {/* Desktop Sidebar (256px) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-white border-r border-earth-200 sticky top-0 h-screen">
        <div className="px-6 py-5 border-b border-earth-200">
          <button
            type="button"
            onClick={() => navigateTo('overview')}
            className="text-lg font-semibold tracking-tight text-earth-900 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Foothold
          </button>
        </div>

        <nav aria-label="Workspace navigation" className="flex-1 p-4 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-sage-50 text-sage-800'
                    : 'text-earth-600 hover:text-earth-900 hover:bg-earth-50'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    active ? 'text-sage-700' : 'text-earth-400'
                  }`}
                  aria-hidden="true"
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-earth-200 space-y-3">
          <div className="text-xs text-earth-500">Current Focus</div>
          <div className="text-xs font-semibold text-earth-900">
            {currentStageMeta.number}: {currentStageMeta.label}
          </div>
          <button
            type="button"
            onClick={() => setShowIntake(true)}
            className="w-full px-3 py-2 text-xs font-medium text-earth-700 bg-earth-100 hover:bg-earth-200/80 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Calibrate My Stage
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-earth-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-64 max-w-[80vw] bg-white h-full border-r border-earth-200 flex flex-col z-10">
            <div className="px-5 py-4 border-b border-earth-200 flex items-center justify-between">
              <span className="text-lg font-semibold tracking-tight text-earth-900">
                Foothold
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation"
                className="p-1.5 text-earth-500 hover:text-earth-900 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-4 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateTo(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                      active
                        ? 'bg-sage-50 text-sage-800'
                        : 'text-earth-600 hover:text-earth-900 hover:bg-earth-50'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-earth-200">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setShowIntake(true);
                }}
                className="w-full px-3 py-2 text-xs font-medium text-earth-700 bg-earth-100 rounded-lg cursor-pointer"
              >
                Calibrate My Stage
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: Breadcrumb on left, 1-2 clean actions on right */}
        <header className="bg-white border-b border-earth-200 px-4 sm:px-8 py-3.5 sticky top-0 z-30">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-6">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open menu"
                className="lg:hidden p-1.5 text-earth-600 hover:text-earth-900 rounded-md hover:bg-earth-100 cursor-pointer"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="text-sm text-earth-500 truncate">
                <span className="lg:hidden font-semibold tracking-tight text-earth-900 mr-2">
                  Foothold
                </span>
                <span className="hidden sm:inline">Workspace / </span>
                <span className="font-medium text-earth-900">{currentNavLabel}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setDiscreetMode(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-earth-700 bg-earth-100 hover:bg-earth-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                title="Switch screen immediately to a neutral weather & notes page"
              >
                <EyeOff className="w-3.5 h-3.5" aria-hidden="true" />
                Quick Exit
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-8 py-8">
          <div className="max-w-6xl mx-auto">
            {activeTab === 'overview' && (
              <OverviewView
                state={state}
                onNavigate={navigateTo}
                onUpdateTaskStatus={handleUpdateTaskStatus}
                onOpenIntake={() => setShowIntake(true)}
                onOpenGuide={() => setGuideOpen(true)}
              />
            )}

            {activeTab === 'roadmap' && (
              <RoadmapView
                tasks={state.tasks}
                currentStage={state.stage}
                onUpdateTaskStatus={handleUpdateTaskStatus}
                onAddTask={handleAddTask}
              />
            )}

            {activeTab === 'vault' && (
              <VaultView
                accounts={state.accounts}
                onUpdateAccount={handleUpdateAccount}
                onAddAccount={handleAddAccount}
              />
            )}

            {activeTab === 'clarity' && (
              <ClaritySandboxView
                budget={state.budget}
                onChangeBudget={handleBudgetChange}
              />
            )}

            {activeTab === 'protection' && (
              <ProtectionLedgerView
                expenses={state.splitExpenses}
                beneficiaries={state.beneficiaries}
                onAddExpense={handleAddExpense}
                onUpdateExpenseStatus={handleUpdateExpenseStatus}
                onUpdateBeneficiary={handleUpdateBeneficiary}
              />
            )}
          </div>
        </main>

        <footer className="border-t border-earth-200 bg-white px-4 sm:px-8 py-4">
          <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-earth-500">
            <span>
              Foothold · Stored privately in your browser for educational planning (not legal or tax advice).
            </span>
            <button
              type="button"
              onClick={() => setShowIntake(true)}
              className="text-earth-600 hover:text-earth-900 underline underline-offset-4 cursor-pointer"
            >
              Adjust stage or reset sample data
            </button>
          </div>
        </footer>
      </div>

      {showIntake && (
        <IntakeModal
          currentStage={state.stage}
          currentComfort={state.comfortLevel}
          currentFocus={state.urgentFocus}
          onSave={handleSaveIntake}
          onResetDemo={handleResetDemo}
          onClose={() => setShowIntake(false)}
        />
      )}

      <JourneyGuideChat
        state={state}
        activeTab={activeTab}
        isOpen={guideOpen}
        onToggleOpen={setGuideOpen}
        onNavigate={(tab) => {
          navigateTo(tab);
          if (typeof window !== 'undefined' && window.innerWidth < 640) {
            setGuideOpen(false);
          }
        }}
      />
    </div>
  );
}
