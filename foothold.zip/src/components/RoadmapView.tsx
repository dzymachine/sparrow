import { useState } from 'react';
import { Check, Clock, Circle, Copy, Plus, Search, X } from 'lucide-react';
import { JourneyStage, RoadmapTask, TaskStatus } from '../types';
import { STAGE_META } from '../data/initialData';

interface RoadmapViewProps {
  tasks: RoadmapTask[];
  currentStage: JourneyStage;
  onUpdateTaskStatus: (taskId: string, status: TaskStatus) => void;
  onAddTask: (title: string, stage: JourneyStage, duration: string, whyItMatters: string) => void;
}

export function RoadmapView({
  tasks,
  currentStage,
  onUpdateTaskStatus,
  onAddTask,
}: RoadmapViewProps) {
  const [stageFilter, setStageFilter] = useState<'all' | JourneyStage>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | TaskStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(tasks[0]?.id ?? null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // New task form state
  const [newTitle, setNewTitle] = useState('');
  const [newStage, setNewStage] = useState<JourneyStage>(currentStage);
  const [newDuration, setNewDuration] = useState('15 min');
  const [newWhy, setNewWhy] = useState('');

  const filteredTasks = tasks.filter((t) => {
    if (stageFilter !== 'all' && t.stage !== stageFilter) return false;
    if (statusFilter !== 'all' && t.status !== statusFilter) return false;
    if (
      searchQuery.trim() &&
      !t.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !t.whyItMatters.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const selectedTask = tasks.find((t) => t.id === selectedTaskId) ?? filteredTasks[0] ?? null;

  const handleCopy = async (task: RoadmapTask) => {
    if (!task.scriptBody) return;
    try {
      await navigator.clipboard.writeText(task.scriptBody);
      setCopiedId(task.id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddTask(
      newTitle.trim(),
      newStage,
      newDuration.trim() || '15 min',
      newWhy.trim() || 'Personal step added to your private separation roadmap.'
    );
    setNewTitle('');
    setNewWhy('');
    setShowAddForm(false);
  };

  const doneCount = tasks.filter((t) => t.status === 'done').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs text-earth-500">
            5-Stage Journey · {doneCount} of {tasks.length} steps finished
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold text-earth-900 mt-1">
            Step-by-Step Separation Roadmap
          </h1>
        </div>
        <button
          type="button"
          onClick={() => setShowAddForm((prev) => !prev)}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          Add Personal Step
        </button>
      </div>

      {showAddForm && (
        <form
          onSubmit={handleCreateTask}
          className="bg-white border border-earth-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-earth-900">Add a Custom Step</h2>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-earth-400 hover:text-earth-700 cursor-pointer"
              aria-label="Close form"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Step Title
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g., Call pediatric dentist about solo billing"
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Phase
              </label>
              <select
                value={newStage}
                onChange={(e) => setNewStage(e.target.value as JourneyStage)}
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-sage-700"
              >
                {(Object.keys(STAGE_META) as JourneyStage[]).map((key) => (
                  <option key={key} value={key}>
                    {STAGE_META[key].shortLabel}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Estimated Time
              </label>
              <input
                type="text"
                value={newDuration}
                onChange={(e) => setNewDuration(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Note / Why It Matters
              </label>
              <input
                type="text"
                value={newWhy}
                onChange={(e) => setNewWhy(e.target.value)}
                placeholder="Optional reminder for yourself"
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 cursor-pointer"
            >
              Save Step
            </button>
          </div>
        </form>
      )}

      {/* Filter Bar */}
      <div className="bg-white border border-earth-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-earth-100 rounded-lg">
          <button
            type="button"
            onClick={() => setStageFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              stageFilter === 'all'
                ? 'bg-white text-earth-900 shadow-sm'
                : 'text-earth-600 hover:text-earth-900'
            }`}
          >
            All Phases
          </button>
          {(Object.keys(STAGE_META) as JourneyStage[]).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setStageFilter(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                stageFilter === key
                  ? 'bg-white text-earth-900 shadow-sm'
                  : 'text-earth-600 hover:text-earth-900'
              }`}
            >
              {STAGE_META[key].shortLabel}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 sm:flex-initial">
            <Search
              className="w-4 h-4 text-earth-400 absolute left-3 top-1/2 -translate-y-1/2"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search steps..."
              className="w-full sm:w-52 pl-9 pr-3 py-1.5 text-xs border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
            />
          </div>

          <select
            aria-label="Filter by status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'all' | TaskStatus)}
            className="px-3 py-1.5 text-xs font-medium border border-earth-200 rounded-lg bg-white text-earth-700 focus:outline-none focus:ring-2 focus:ring-sage-700"
          >
            <option value="all">All Statuses</option>
            <option value="todo">To Do</option>
            <option value="waiting">Waiting</option>
            <option value="done">Done</option>
          </select>
        </div>
      </div>

      {/* Master-Detail Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Task List */}
        <div className="lg:col-span-7 bg-white border border-earth-200 rounded-xl divide-y divide-earth-200">
          {filteredTasks.length === 0 ? (
            <div className="p-8 text-center space-y-2">
              <p className="text-sm font-medium text-earth-900">No steps match this filter</p>
              <p className="text-xs text-earth-500">
                Try clearing your search or switching back to All Phases.
              </p>
              <button
                type="button"
                onClick={() => {
                  setStageFilter('all');
                  setStatusFilter('all');
                  setSearchQuery('');
                }}
                className="mt-2 px-3 py-1.5 text-xs font-medium text-sage-800 bg-sage-50 rounded-md hover:bg-sage-100 cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            filteredTasks.map((task) => {
              const isSelected = selectedTask?.id === task.id;
              return (
                <div
                  key={task.id}
                  className={`p-4 sm:px-5 transition-colors flex items-start justify-between gap-4 ${
                    isSelected ? 'bg-sage-50/70' : 'hover:bg-earth-50/80'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedTaskId(task.id)}
                    className="text-left flex-1 space-y-1 cursor-pointer"
                  >
                    <div className="text-xs text-earth-500">
                      {STAGE_META[task.stage].shortLabel} · {task.duration}
                      {task.scriptBody && ' · Includes script'}
                    </div>
                    <div
                      className={`text-sm font-semibold ${
                        task.status === 'done'
                          ? 'text-earth-400 line-through'
                          : 'text-earth-900'
                      }`}
                    >
                      {task.title}
                    </div>
                  </button>

                  <div className="flex items-center gap-1.5 shrink-0 pt-1">
                    {task.status === 'done' && (
                      <span className="text-xs font-medium text-sage-700 mr-1">Done</span>
                    )}
                    {task.status === 'waiting' && (
                      <span className="text-xs font-medium text-amber-800 mr-1">Waiting</span>
                    )}
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateTaskStatus(
                          task.id,
                          task.status === 'done' ? 'todo' : 'done'
                        )
                      }
                      aria-label={
                        task.status === 'done' ? 'Mark as to do' : 'Mark as done'
                      }
                      className={`p-1.5 rounded-md border transition-colors cursor-pointer ${
                        task.status === 'done'
                          ? 'bg-sage-700 border-sage-700 text-white'
                          : 'bg-white border-earth-200 text-earth-400 hover:text-sage-700 hover:border-sage-700'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Detail & Script Guide Panel */}
        <div className="lg:col-span-5 bg-white border border-earth-200 rounded-xl p-6 sticky top-24">
          {selectedTask ? (
            <div className="space-y-5">
              <div>
                <div className="text-xs text-earth-500">
                  {STAGE_META[selectedTask.stage].number}:{' '}
                  {STAGE_META[selectedTask.stage].label} · {selectedTask.duration}
                </div>
                <h2 className="text-xl font-semibold text-earth-900 mt-1">
                  {selectedTask.title}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onUpdateTaskStatus(selectedTask.id, 'todo')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedTask.status === 'todo'
                      ? 'bg-earth-800 text-white border-earth-800'
                      : 'bg-white text-earth-600 border-earth-200 hover:bg-earth-50'
                  }`}
                >
                  <Circle className="w-3 h-3" aria-hidden="true" />
                  To Do
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateTaskStatus(selectedTask.id, 'waiting')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedTask.status === 'waiting'
                      ? 'bg-amber-700 text-white border-amber-700'
                      : 'bg-white text-earth-600 border-earth-200 hover:bg-earth-50'
                  }`}
                >
                  <Clock className="w-3 h-3" aria-hidden="true" />
                  Waiting
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateTaskStatus(selectedTask.id, 'done')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedTask.status === 'done'
                      ? 'bg-sage-700 text-white border-sage-700'
                      : 'bg-white text-earth-600 border-earth-200 hover:bg-earth-50'
                  }`}
                >
                  <Check className="w-3 h-3" aria-hidden="true" />
                  Done
                </button>
              </div>

              <div className="pt-4 border-t border-earth-100 space-y-2">
                <h3 className="text-xs font-semibold text-earth-800">Why this matters</h3>
                <p className="text-sm text-earth-600 leading-relaxed">
                  {selectedTask.whyItMatters}
                </p>
              </div>

              <div className="pt-4 border-t border-earth-100 space-y-2">
                <h3 className="text-xs font-semibold text-earth-800">Exact steps</h3>
                <ol className="space-y-2 text-sm text-earth-700 list-decimal list-inside">
                  {selectedTask.steps.map((s, idx) => (
                    <li key={idx} className="leading-relaxed">
                      {s}
                    </li>
                  ))}
                </ol>
              </div>

              {selectedTask.scriptBody && (
                <div className="pt-4 border-t border-earth-100">
                  <div className="bg-earth-50 border border-earth-200 rounded-lg p-4 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-earth-800">
                        {selectedTask.scriptTitle ?? 'Copy-Paste Script'}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(selectedTask)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-sage-800 hover:text-sage-900 cursor-pointer"
                      >
                        {copiedId === selectedTask.id ? (
                          <>
                            <Check className="w-3.5 h-3.5" aria-hidden="true" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                            Copy Script
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="text-xs text-earth-700 whitespace-pre-wrap font-sans leading-relaxed">
                      {selectedTask.scriptBody}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-earth-500">Select a step to view instructions.</p>
          )}
        </div>
      </div>
    </div>
  );
}
