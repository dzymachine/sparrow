import { useState } from 'react';
import { X, ArrowRight, RotateCcw } from 'lucide-react';
import { ComfortLevel, JourneyStage } from '../types';
import { STAGE_META } from '../data/initialData';

interface IntakeModalProps {
  currentStage: JourneyStage;
  currentComfort: ComfortLevel;
  currentFocus: string[];
  onSave: (stage: JourneyStage, comfort: ComfortLevel, focus: string[]) => void;
  onResetDemo: () => void;
  onClose: () => void;
}

const URGENT_OPTIONS = [
  'See what I can afford solo',
  'Untangle joint accounts',
  'Gather statements privately',
  'Compare keeping the house vs. renting',
  'Track shared child expenses',
  'Start building my own credit & savings',
];

const COMFORT_OPTIONS: { value: ComfortLevel; title: string; desc: string }[] = [
  {
    value: 'beginner',
    title: 'Explain everything in plain English',
    desc: 'I rarely handled household finances and want clear, jargon-free context.',
  },
  {
    value: 'basics',
    title: 'I know the basics, just need a map',
    desc: 'I manage day-to-day bills, but divorce splits, QDROs, and taxes feel overwhelming.',
  },
  {
    value: 'comfortable',
    title: 'Comfortable with numbers, need structure',
    desc: 'I want an organized tracker and scenario tools without extra hand-holding.',
  },
];

export function IntakeModal({
  currentStage,
  currentComfort,
  currentFocus,
  onSave,
  onResetDemo,
  onClose,
}: IntakeModalProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [stage, setStage] = useState<JourneyStage>(currentStage);
  const [focus, setFocus] = useState<string[]>(currentFocus);
  const [comfort, setComfort] = useState<ComfortLevel>(currentComfort);

  const toggleFocus = (item: string) => {
    setFocus((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item]
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-earth-900/40 backdrop-blur-[2px] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="intake-heading"
    >
      <div className="bg-white border border-earth-200 rounded-xl w-full max-w-2xl shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-earth-200 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs text-earth-500">Step {step} of 3 · Private Calibration</p>
            <h2 id="intake-heading" className="text-xl font-semibold text-earth-900">
              Tailor Your Foothold Workspace
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 text-earth-500 hover:text-earth-900 rounded-lg hover:bg-earth-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {step === 1 && (
            <div className="space-y-3">
              <p className="text-sm font-medium text-earth-900">
                1. Where are you in your separation journey right now?
              </p>
              <p className="text-xs text-earth-500">
                This prioritizes your Next 3 Moves and overview guidance. Nothing is shared externally.
              </p>
              <div className="space-y-2.5 pt-1">
                {(Object.keys(STAGE_META) as JourneyStage[]).map((key) => {
                  const meta = STAGE_META[key];
                  const active = stage === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setStage(key)}
                      className={`w-full text-left p-4 rounded-lg border transition-colors cursor-pointer ${
                        active
                          ? 'border-sage-700 bg-sage-50'
                          : 'border-earth-200 bg-white hover:bg-earth-50'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-sm font-semibold text-earth-900">
                          {meta.number}: {meta.label}
                        </span>
                        <span className="text-xs font-medium text-sage-800 whitespace-nowrap shrink-0">
                          {active ? 'Selected' : 'Select'}
                        </span>
                      </div>
                      <p className="text-xs text-earth-600 mt-1">{meta.headline}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <p className="text-sm font-medium text-earth-900">
                2. What feels most urgent for you this week?
              </p>
              <p className="text-xs text-earth-500">
                Choose as many as apply. You can change these anytime.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {URGENT_OPTIONS.map((item) => {
                  const selected = focus.includes(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleFocus(item)}
                      className={`text-left p-3.5 rounded-lg border text-sm transition-colors cursor-pointer ${
                        selected
                          ? 'border-sage-700 bg-sage-50 text-earth-900 font-medium'
                          : 'border-earth-200 bg-white text-earth-700 hover:bg-earth-50'
                      }`}
                    >
                      {item}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3">
              <p className="text-sm font-medium text-earth-900">
                3. How comfortable do you feel with financial terms?
              </p>
              <p className="text-xs text-earth-500">
                No judgment—half of our members are managing solo accounts for the very first time.
              </p>
              <div className="space-y-2.5 pt-1">
                {COMFORT_OPTIONS.map((opt) => {
                  const active = comfort === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setComfort(opt.value)}
                      className={`w-full text-left p-4 rounded-lg border transition-colors cursor-pointer ${
                        active
                          ? 'border-sage-700 bg-sage-50'
                          : 'border-earth-200 bg-white hover:bg-earth-50'
                      }`}
                    >
                      <div className="text-sm font-semibold text-earth-900">{opt.title}</div>
                      <p className="text-xs text-earth-600 mt-1">{opt.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 bg-earth-50 border-t border-earth-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              onResetDemo();
              onClose();
            }}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-earth-600 hover:text-earth-900 py-2 px-3 rounded-md hover:bg-earth-200/60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            Reset Sample Data
          </button>

          <div className="flex items-center gap-2">
            {step > 1 && (
              <button
                type="button"
                onClick={() => setStep((s) => (s === 3 ? 2 : 1))}
                className="px-4 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Back
              </button>
            )}
            {step < 3 ? (
              <button
                type="button"
                onClick={() => setStep((s) => (s === 1 ? 2 : 3))}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Continue
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  onSave(stage, comfort, focus);
                  onClose();
                }}
                className="px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Save My Preferences
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
