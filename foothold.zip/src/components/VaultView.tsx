import { useState } from 'react';
import { Download, Plus, Search, X } from 'lucide-react';
import { AccountItem, AccountStatus, AccountType } from '../types';
import { downloadCsv, formatCurrency } from '../utils/format';

interface VaultViewProps {
  accounts: AccountItem[];
  onUpdateAccount: (updated: AccountItem) => void;
  onAddAccount: (account: Omit<AccountItem, 'id'>) => void;
}

const STATUS_LABELS: Record<AccountStatus, string> = {
  shared: 'Still Shared',
  in_progress: 'In Progress',
  solo: 'Solo / Closed',
  unknown: 'Unknown (Discovery)',
};

const ACCOUNT_TYPES: AccountType[] = [
  'Checking',
  'Savings',
  'Credit Card',
  'Mortgage / Lease',
  'Retirement',
  'Insurance',
  'Utility / Bill',
];

export function VaultView({ accounts, onUpdateAccount, onAddAccount }: VaultViewProps) {
  const [filter, setFilter] = useState<'all' | AccountStatus>('all');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(accounts[0]?.id ?? null);
  const [showAdd, setShowAdd] = useState(false);

  // Add account state
  const [name, setName] = useState('');
  const [institution, setInstitution] = useState('');
  const [type, setType] = useState<AccountType>('Checking');
  const [balanceUnknown, setBalanceUnknown] = useState(false);
  const [balanceInput, setBalanceInput] = useState('');
  const [isDebt, setIsDebt] = useState(false);
  const [status, setStatus] = useState<AccountStatus>('shared');
  const [notes, setNotes] = useState('');

  const filtered = accounts.filter((a) => {
    if (filter !== 'all' && a.status !== filter) return false;
    if (
      search.trim() &&
      !a.name.toLowerCase().includes(search.toLowerCase()) &&
      !a.institution.toLowerCase().includes(search.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const selected = accounts.find((a) => a.id === selectedId) ?? filtered[0] ?? null;

  const totalAssets = accounts
    .filter((a) => !a.isDebt && a.balance !== null)
    .reduce((sum, a) => sum + (a.balance ?? 0), 0);

  const totalDebts = accounts
    .filter((a) => a.isDebt && a.balance !== null)
    .reduce((sum, a) => sum + (a.balance ?? 0), 0);

  const unknownCount = accounts.filter((a) => a.status === 'unknown' || a.balance === null).length;

  const handleExportCsv = () => {
    downloadCsv(
      'foothold-account-discovery-summary.csv',
      ['Account Name', 'Institution', 'Type', 'Asset or Debt', 'Balance', 'Status', 'Notes'],
      accounts.map((a) => [
        a.name,
        a.institution,
        a.type,
        a.isDebt ? 'Debt' : 'Asset / Policy',
        a.balance === null ? 'Unknown - Request in Discovery' : a.balance,
        STATUS_LABELS[a.status],
        a.notes,
      ])
    );
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const parsedBalance = balanceUnknown
      ? null
      : Number(balanceInput.replace(/[^0-9.-]/g, '')) || 0;

    onAddAccount({
      name: name.trim(),
      institution: institution.trim() || 'Unspecified',
      type,
      balance: parsedBalance,
      isDebt,
      status: balanceUnknown ? 'unknown' : status,
      checks: {
        myNameOnly: status === 'solo',
        exRemoved: status === 'solo',
        autopayMoved: status === 'solo',
        passwordUpdated: status === 'solo',
      },
      notes: notes.trim(),
    });
    setName('');
    setInstitution('');
    setBalanceInput('');
    setBalanceUnknown(false);
    setNotes('');
    setShowAdd(false);
  };

  const toggleCheck = (
    item: AccountItem,
    key: keyof AccountItem['checks']
  ) => {
    onUpdateAccount({
      ...item,
      checks: {
        ...item.checks,
        [key]: !item.checks[key],
      },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs text-earth-500">
            Private Inventory · No bank logins required · {unknownCount} discovery item(s)
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold text-earth-900 mt-1">
            Account &amp; Untangling Vault
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            Export Discovery CSV
          </button>
          <button
            type="button"
            onClick={() => setShowAdd((p) => !p)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            Add Account
          </button>
        </div>
      </div>

      {/* Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-earth-200 rounded-xl p-4">
          <div className="text-xs text-earth-500">Documented Assets</div>
          <div className="mt-1 text-xl font-mono tabular-nums font-medium text-earth-900">
            {formatCurrency(totalAssets)}
          </div>
        </div>
        <div className="bg-white border border-earth-200 rounded-xl p-4">
          <div className="text-xs text-earth-500">Documented Debts</div>
          <div className="mt-1 text-xl font-mono tabular-nums font-medium text-earth-900">
            {formatCurrency(totalDebts)}
          </div>
        </div>
        <div className="bg-white border border-earth-200 rounded-xl p-4">
          <div className="text-xs text-earth-500">Needs Attorney Discovery</div>
          <div className="mt-1 text-xl font-mono tabular-nums font-medium text-amber-800">
            {unknownCount} account{unknownCount === 1 ? '' : 's'}
          </div>
        </div>
      </div>

      {showAdd && (
        <form
          onSubmit={handleCreate}
          className="bg-white border border-earth-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-earth-900">
              Add Account, Loan, or Policy
            </h2>
            <button
              type="button"
              onClick={() => setShowAdd(false)}
              className="text-earth-400 hover:text-earth-700 cursor-pointer"
              aria-label="Close form"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Account Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Joint High-Yield Savings"
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Institution
              </label>
              <input
                type="text"
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                placeholder="e.g., Bank of America"
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Category
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as AccountType)}
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-sage-700"
              >
                {ACCOUNT_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Approximate Balance ($)
              </label>
              <input
                type="number"
                disabled={balanceUnknown}
                value={balanceInput}
                onChange={(e) => setBalanceInput(e.target.value)}
                placeholder={balanceUnknown ? 'Marked unknown' : '0'}
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg disabled:bg-earth-100 focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Current Status
              </label>
              <select
                disabled={balanceUnknown}
                value={balanceUnknown ? 'unknown' : status}
                onChange={(e) => setStatus(e.target.value as AccountStatus)}
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg bg-white disabled:bg-earth-100 focus:outline-none focus:ring-2 focus:ring-sage-700"
              >
                <option value="shared">Still Shared</option>
                <option value="in_progress">In Progress</option>
                <option value="solo">Solo / Closed</option>
              </select>
            </div>
            <div className="flex flex-col gap-2 pb-1">
              <label className="inline-flex items-center gap-2 text-xs text-earth-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={balanceUnknown}
                  onChange={(e) => setBalanceUnknown(e.target.checked)}
                  className="rounded border-earth-300 text-sage-700 focus:ring-sage-700"
                />
                I don&apos;t know the balance yet (Discovery List)
              </label>
              <label className="inline-flex items-center gap-2 text-xs text-earth-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isDebt}
                  onChange={(e) => setIsDebt(e.target.checked)}
                  className="rounded border-earth-300 text-sage-700 focus:ring-sage-700"
                />
                This is a debt or loan owed
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-earth-700 mb-1">Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Statement downloaded through Oct; need spouse login for latest balance"
              className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAdd(false)}
              className="px-4 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 cursor-pointer"
            >
              Save to Vault
            </button>
          </div>
        </form>
      )}

      {/* Filter Bar */}
      <div className="bg-white border border-earth-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-earth-100 rounded-lg">
          {(
            [
              ['all', 'All Accounts'],
              ['shared', 'Still Shared'],
              ['in_progress', 'In Progress'],
              ['solo', 'Solo / Closed'],
              ['unknown', 'Unknown (Discovery)'],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === key
                  ? 'bg-white text-earth-900 shadow-sm'
                  : 'text-earth-600 hover:text-earth-900'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search
            className="w-4 h-4 text-earth-400 absolute left-3 top-1/2 -translate-y-1/2"
            aria-hidden="true"
          />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search bank or account..."
            className="w-full sm:w-56 pl-9 pr-3 py-1.5 text-xs border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
          />
        </div>
      </div>

      {/* Table + Checklist Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8 bg-white border border-earth-200 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-earth-200 text-xs font-medium text-earth-500">
                <th className="py-3 px-4">Account</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-earth-100 text-sm">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-10 px-4 text-center text-earth-500 text-sm">
                    No accounts match this view. Click &ldquo;Add Account&rdquo; above to log one.
                  </td>
                </tr>
              ) : (
                filtered.map((item) => {
                  const isSel = selected?.id === item.id;
                  return (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedId(item.id)}
                      className={`cursor-pointer transition-colors ${
                        isSel ? 'bg-sage-50/70' : 'hover:bg-earth-50'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-earth-900">{item.name}</div>
                        <div className="text-xs text-earth-500">{item.institution}</div>
                      </td>
                      <td className="py-3 px-4 text-xs text-earth-600 whitespace-nowrap">
                        {item.type}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`text-xs font-medium ${
                            item.status === 'solo'
                              ? 'text-sage-700'
                              : item.status === 'unknown'
                              ? 'text-red-800'
                              : item.status === 'shared'
                              ? 'text-amber-800'
                              : 'text-earth-700'
                          }`}
                        >
                          {STATUS_LABELS[item.status]}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-earth-900 whitespace-nowrap">
                        {item.balance === null ? (
                          <span className="text-xs font-sans text-amber-800">Unknown</span>
                        ) : (
                          <span>
                            {item.isDebt ? '-' : ''}
                            {formatCurrency(item.balance)}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Account Detail & Untangling Checklist */}
        <div className="lg:col-span-4 bg-white border border-earth-200 rounded-xl p-6 space-y-5">
          {selected ? (
            <>
              <div>
                <div className="text-xs text-earth-500">
                  {selected.institution} · {selected.type}
                </div>
                <h2 className="text-lg font-semibold text-earth-900 mt-0.5">
                  {selected.name}
                </h2>
              </div>

              <div>
                <label className="block text-xs font-medium text-earth-700 mb-1.5">
                  Untangling Status
                </label>
                <select
                  value={selected.status}
                  onChange={(e) =>
                    onUpdateAccount({
                      ...selected,
                      status: e.target.value as AccountStatus,
                    })
                  }
                  className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-sage-700"
                >
                  <option value="shared">Still Shared</option>
                  <option value="in_progress">In Progress</option>
                  <option value="solo">Solo / Closed</option>
                  <option value="unknown">Unknown (Discovery List)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-earth-100 space-y-2.5">
                <div className="text-xs font-semibold text-earth-800">
                  Separation Checklist
                </div>
                {(
                  [
                    ['myNameOnly', 'Titled in my name only (or closed)'],
                    ['exRemoved', 'Ex-partner access / card removed'],
                    ['autopayMoved', 'Auto-pay moved to solo account'],
                    ['passwordUpdated', 'Login & security questions updated'],
                  ] as const
                ).map(([key, label]) => (
                  <label
                    key={key}
                    className="flex items-start gap-2.5 text-xs text-earth-700 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={selected.checks[key]}
                      onChange={() => toggleCheck(selected, key)}
                      className="mt-0.5 rounded border-earth-300 text-sage-700 focus:ring-sage-700"
                    />
                    <span>{label}</span>
                  </label>
                ))}
              </div>

              <div className="pt-3 border-t border-earth-100">
                <label className="block text-xs font-semibold text-earth-800 mb-1.5">
                  Notes for Yourself or Attorney
                </label>
                <textarea
                  rows={3}
                  value={selected.notes}
                  onChange={(e) =>
                    onUpdateAccount({ ...selected, notes: e.target.value })
                  }
                  className="w-full px-3 py-2 text-xs text-earth-700 border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
                />
              </div>
            </>
          ) : (
            <p className="text-sm text-earth-500">
              Select an account from the table to inspect its separation checklist.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
