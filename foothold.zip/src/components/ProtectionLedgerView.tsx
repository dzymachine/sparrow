import { useState } from 'react';
import { Download, Plus, X } from 'lucide-react';
import { BeneficiaryItem, SplitExpense } from '../types';
import { downloadCsv, formatCurrencyExact } from '../utils/format';

interface ProtectionLedgerViewProps {
  expenses: SplitExpense[];
  beneficiaries: BeneficiaryItem[];
  onAddExpense: (item: Omit<SplitExpense, 'id'>) => void;
  onUpdateExpenseStatus: (id: string, status: SplitExpense['status']) => void;
  onUpdateBeneficiary: (id: string, status: BeneficiaryItem['currentStatus']) => void;
}

const EXPENSE_STATUS_LABEL: Record<SplitExpense['status'], string> = {
  logged: 'Logged',
  requested: 'Requested',
  reimbursed: 'Reimbursed',
};

const BENEFICIARY_STATUS_LABEL: Record<BeneficiaryItem['currentStatus'], string> = {
  needs_update: 'Needs Update',
  in_progress: 'In Progress',
  updated: 'Updated',
};

export function ProtectionLedgerView({
  expenses,
  beneficiaries,
  onAddExpense,
  onUpdateExpenseStatus,
  onUpdateBeneficiary,
}: ProtectionLedgerViewProps) {
  const [showAdd, setShowAdd] = useState(false);
  const [date, setDate] = useState('2026-11-13');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<SplitExpense['category']>('Medical');
  const [totalAmount, setTotalAmount] = useState('');
  const [mySharePercent, setMySharePercent] = useState(50);
  const [paidByMe, setPaidByMe] = useState(true);
  const [note, setNote] = useState('');

  // Calculate net owed to user across non-reimbursed items
  const netOwedToMe = expenses
    .filter((e) => e.status !== 'reimbursed')
    .reduce((sum, e) => {
      const otherShare = e.totalAmount * ((100 - e.mySharePercent) / 100);
      const myShare = e.totalAmount * (e.mySharePercent / 100);
      return e.paidByMe ? sum + otherShare : sum - myShare;
    }, 0);

  const openItemsCount = expenses.filter((e) => e.status !== 'reimbursed').length;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number(totalAmount);
    if (!description.trim() || !amount || amount <= 0) return;

    onAddExpense({
      date,
      description: description.trim(),
      category,
      totalAmount: amount,
      mySharePercent,
      paidByMe,
      status: 'logged',
      note: note.trim(),
    });
    setDescription('');
    setTotalAmount('');
    setNote('');
    setShowAdd(false);
  };

  const handleExportLedger = () => {
    downloadCsv(
      'foothold-coparenting-expenses.csv',
      ['Date', 'Description', 'Category', 'Total ($)', 'My Share %', 'Paid By', 'Owed to Me ($)', 'Status', 'Note'],
      expenses.map((e) => {
        const owed = e.paidByMe
          ? e.totalAmount * ((100 - e.mySharePercent) / 100)
          : -(e.totalAmount * (e.mySharePercent / 100));
        return [
          e.date,
          e.description,
          e.category,
          e.totalAmount.toFixed(2),
          `${e.mySharePercent}%`,
          e.paidByMe ? 'Me' : 'Co-Parent',
          owed.toFixed(2),
          EXPENSE_STATUS_LABEL[e.status],
          e.note,
        ];
      })
    );
  };

  const updatedBeneficiaryCount = beneficiaries.filter(
    (b) => b.currentStatus === 'updated'
  ).length;

  return (
    <div className="space-y-8">
      {/* Section 1: Co-Parenting Split Ledger */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs text-earth-500">
              Neutral Shared Records · {openItemsCount} open item(s)
            </p>
            <h1 className="text-2xl sm:text-3xl font-semibold text-earth-900 mt-1">
              Co-Parenting Ledger &amp; Protection Reset
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleExportLedger}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              Export Neutral CSV
            </button>
            <button
              type="button"
              onClick={() => setShowAdd((p) => !p)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              Log Shared Expense
            </button>
          </div>
        </div>

        {/* Net Balance Strip */}
        <div className="bg-white border border-earth-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-earth-500">Current Open Net Balance</div>
            <div className="text-lg font-semibold text-earth-900 mt-0.5">
              {netOwedToMe >= 0
                ? `You are owed ${formatCurrencyExact(netOwedToMe)} across open expenses`
                : `You owe ${formatCurrencyExact(Math.abs(netOwedToMe))} across open expenses`}
            </div>
          </div>
          <p className="text-xs text-earth-500 max-w-sm">
            Keep logs factual and receipt-backed so you can export a neutral monthly summary without emotional back-and-forth.
          </p>
        </div>

        {showAdd && (
          <form
            onSubmit={handleCreate}
            className="bg-white border border-earth-200 rounded-xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-earth-900">
                Log a Shared Child Expense
              </h2>
              <button
                type="button"
                onClick={() => setShowAdd(false)}
                className="text-earth-400 hover:text-earth-700 cursor-pointer"
                aria-label="Close form"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-earth-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-earth-700 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g., Orthodontist co-pay"
                  className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-earth-700 mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) =>
                    setCategory(e.target.value as SplitExpense['category'])
                  }
                  className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-sage-700"
                >
                  <option value="Medical">Medical</option>
                  <option value="School">School</option>
                  <option value="Activities">Activities</option>
                  <option value="Childcare">Childcare</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
              <div>
                <label className="block text-xs font-medium text-earth-700 mb-1">
                  Total Receipt Amount ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={totalAmount}
                  onChange={(e) => setTotalAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-earth-700 mb-1">
                  My Share (%)
                </label>
                <select
                  value={mySharePercent}
                  onChange={(e) => setMySharePercent(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-sage-700"
                >
                  <option value={50}>50% / 50%</option>
                  <option value={40}>40% Me / 60% Co-parent</option>
                  <option value={60}>60% Me / 40% Co-parent</option>
                  <option value={30}>30% Me / 70% Co-parent</option>
                </select>
              </div>
              <div className="pb-2">
                <label className="inline-flex items-center gap-2 text-xs text-earth-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paidByMe}
                    onChange={(e) => setPaidByMe(e.target.checked)}
                    className="rounded border-earth-300 text-sage-700 focus:ring-sage-700"
                  />
                  I paid this bill upfront
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-earth-700 mb-1">
                Factual Note / Receipt Reference
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Optional note (e.g., Invoice #412 emailed Nov 13)"
                className="w-full px-3 py-2 text-sm border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAdd(false)}
                className="px-4 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 cursor-pointer"
              >
                Save Expense
              </button>
            </div>
          </form>
        )}

        <div className="bg-white border border-earth-200 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-earth-200 text-xs font-medium text-earth-500">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Expense</th>
                <th className="py-3 px-4">Split</th>
                <th className="py-3 px-4 text-right">Total</th>
                <th className="py-3 px-4 text-right">Reimbursement</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-earth-100 text-sm">
              {expenses.map((exp) => {
                const otherShare = exp.totalAmount * ((100 - exp.mySharePercent) / 100);
                const myShare = exp.totalAmount * (exp.mySharePercent / 100);
                const netForRow = exp.paidByMe ? otherShare : -myShare;
                return (
                  <tr key={exp.id} className="hover:bg-earth-50">
                    <td className="py-3 px-4 font-mono tabular-nums text-xs text-earth-500 whitespace-nowrap">
                      {exp.date}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-earth-900">{exp.description}</div>
                      <div className="text-xs text-earth-500">
                        {exp.category}
                        {exp.note && ` · ${exp.note}`}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-xs text-earth-600 whitespace-nowrap">
                      {exp.mySharePercent}% / {100 - exp.mySharePercent}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-earth-900 whitespace-nowrap">
                      {formatCurrencyExact(exp.totalAmount)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-earth-900 whitespace-nowrap">
                      {exp.status === 'reimbursed' ? (
                        <span className="text-xs font-sans text-earth-400">Settled</span>
                      ) : (
                        <span className={netForRow >= 0 ? 'text-sage-700' : 'text-amber-800'}>
                          {netForRow >= 0 ? '+' : ''}
                          {formatCurrencyExact(netForRow)}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <select
                        aria-label={`Status for ${exp.description}`}
                        value={exp.status}
                        onChange={(e) =>
                          onUpdateExpenseStatus(
                            exp.id,
                            e.target.value as SplitExpense['status']
                          )
                        }
                        className="px-2.5 py-1 text-xs font-medium border border-earth-200 rounded-md bg-white text-earth-700 focus:outline-none focus:ring-2 focus:ring-sage-700"
                      >
                        <option value="logged">Logged</option>
                        <option value="requested">Requested</option>
                        <option value="reimbursed">Reimbursed</option>
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Section 2: Beneficiary & Benefits Reset Checklist */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <p className="text-xs text-earth-500">
              Post-Decree Protection · {updatedBeneficiaryCount} of {beneficiaries.length} updated
            </p>
            <h2 className="text-xl font-semibold text-earth-900 mt-0.5">
              Beneficiary &amp; Benefits Reset Checklist
            </h2>
          </div>
        </div>

        <div className="bg-white border border-earth-200 rounded-xl divide-y divide-earth-200">
          {beneficiaries.map((item) => (
            <div
              key={item.id}
              className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1 max-w-2xl">
                <div className="text-xs text-earth-500">
                  {item.category} · {BENEFICIARY_STATUS_LABEL[item.currentStatus]}
                </div>
                <div className="text-sm font-semibold text-earth-900">
                  {item.accountName}
                </div>
                <p className="text-xs text-earth-600 leading-relaxed">{item.guidance}</p>
              </div>

              <div className="shrink-0">
                <select
                  aria-label={`Beneficiary status for ${item.accountName}`}
                  value={item.currentStatus}
                  onChange={(e) =>
                    onUpdateBeneficiary(
                      item.id,
                      e.target.value as BeneficiaryItem['currentStatus']
                    )
                  }
                  className={`px-3 py-1.5 text-xs font-medium border rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-sage-700 ${
                    item.currentStatus === 'updated'
                      ? 'border-sage-300 text-sage-800'
                      : item.currentStatus === 'needs_update'
                      ? 'border-amber-300 text-amber-800'
                      : 'border-earth-200 text-earth-700'
                  }`}
                >
                  <option value="needs_update">Needs Update</option>
                  <option value="in_progress">In Progress</option>
                  <option value="updated">Updated</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
