import { useState } from 'react';
import { BudgetState } from '../types';
import { formatCurrency } from '../utils/format';

interface ClaritySandboxViewProps {
  budget: BudgetState;
  onChangeBudget: (next: BudgetState) => void;
}

export function ClaritySandboxView({ budget, onChangeBudget }: ClaritySandboxViewProps) {
  const [subTab, setSubTab] = useState<'baseline' | 'sandbox'>('baseline');

  // Sandbox local simulation sliders
  const [keepMortgage, setKeepMortgage] = useState(budget.mustPays.housing);
  const [keepTaxIns, setKeepTaxIns] = useState(420);
  const [keepUpkeep, setKeepUpkeep] = useState(250);
  const [rentAmount, setRentAmount] = useState(1650);
  const [rentUtilitiesDelta, setRentUtilitiesDelta] = useState(-90);

  // Work & Childcare tradeoff sliders
  const [grossMonthlyPay, setGrossMonthlyPay] = useState(5200);
  const [taxRatePct, setTaxRatePct] = useState(22);
  const [monthlyChildcare, setMonthlyChildcare] = useState(850);

  // Calculations for Baseline
  const steadyIncome =
    budget.netPaycheck + budget.reliableSupport + budget.otherSteadyIncome;
  const transitionalPool = budget.soloCashAvailable + budget.expectedSettlementCash;

  const mustPaysTotal = Object.values(budget.mustPays).reduce((a, b) => a + b, 0);
  const lifeAndKidsTotal = Object.values(budget.lifeAndKids).reduce((a, b) => a + b, 0);
  const totalOutflows = mustPaysTotal + lifeAndKidsTotal;
  const breathingRoom = steadyIncome - totalOutflows;

  const oneMonthTarget = totalOutflows;
  const threeMonthTarget = totalOutflows * 3;
  const sixMonthTarget = totalOutflows * 6;
  const cushionPctOfSixMonths = Math.min(
    100,
    Math.round((budget.soloCashAvailable / Math.max(1, sixMonthTarget)) * 100)
  );

  // Housing Sandbox calculations
  const nonHousingExpenses = totalOutflows - budget.mustPays.housing;
  const keepTotalHousing = keepMortgage + keepTaxIns + keepUpkeep;
  const keepLeftover = steadyIncome - (nonHousingExpenses + keepTotalHousing);
  const rentTotalHousing = rentAmount + Math.max(0, rentUtilitiesDelta);
  const rentLeftover = steadyIncome - (nonHousingExpenses + rentTotalHousing);
  const monthlyDifference = rentLeftover - keepLeftover;

  // Work / Childcare calculations
  const estimatedTaxes = Math.round(grossMonthlyPay * (taxRatePct / 100));
  const trueNetFromWork = grossMonthlyPay - estimatedTaxes - monthlyChildcare;

  const updateIncome = (
    field: 'netPaycheck' | 'reliableSupport' | 'otherSteadyIncome' | 'soloCashAvailable' | 'expectedSettlementCash',
    val: number
  ) => {
    onChangeBudget({ ...budget, [field]: Math.max(0, val) });
  };

  const updateMustPay = (field: keyof BudgetState['mustPays'], val: number) => {
    onChangeBudget({
      ...budget,
      mustPays: { ...budget.mustPays, [field]: Math.max(0, val) },
    });
  };

  const updateLifeKids = (field: keyof BudgetState['lifeAndKids'], val: number) => {
    onChangeBudget({
      ...budget,
      lifeAndKids: { ...budget.lifeAndKids, [field]: Math.max(0, val) },
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs text-earth-500">
            Plain-English Cash Flow &amp; Major Decisions
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold text-earth-900 mt-1">
            New Baseline &amp; Decision Sandbox
          </h1>
        </div>

        <div className="inline-flex items-center gap-1 p-1 bg-earth-100 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setSubTab('baseline')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'baseline'
                ? 'bg-white text-earth-900 shadow-sm'
                : 'text-earth-600 hover:text-earth-900'
            }`}
          >
            My New Baseline
          </button>
          <button
            type="button"
            onClick={() => setSubTab('sandbox')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'sandbox'
                ? 'bg-white text-earth-900 shadow-sm'
                : 'text-earth-600 hover:text-earth-900'
            }`}
          >
            Can I Afford This? Sandbox
          </button>
        </div>
      </div>

      {subTab === 'baseline' ? (
        <div className="space-y-6">
          {/* Calm Headline Verdict */}
          <section className="bg-white border border-earth-200 rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-1 max-w-2xl">
              <div className="text-xs text-earth-500">
                Steady Monthly Cash Flow · Excludes one-time settlement funds
              </div>
              <h2 className="text-xl sm:text-2xl font-semibold text-earth-900">
                {breathingRoom >= 0
                  ? `After essentials, you have ${formatCurrency(breathingRoom)}/month of breathing room.`
                  : `Your steady baseline has a ${formatCurrency(Math.abs(breathingRoom))}/month gap right now.`}
              </h2>
              <p className="text-sm text-earth-600">
                {breathingRoom >= 0
                  ? 'You can direct this monthly surplus into your solo emergency cushion or long-term independence.'
                  : `Your ${formatCurrency(transitionalPool)} transitional pool could cover this gap for roughly ${Math.max(
                      1,
                      Math.floor(transitionalPool / Math.max(1, Math.abs(breathingRoom)))
                    )} months while you adjust housing or income.`}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 shrink-0 border-t lg:border-t-0 lg:border-l border-earth-200 pt-4 lg:pt-0 lg:pl-6">
              <div>
                <div className="text-xs text-earth-500">Steady Inflow</div>
                <div className="text-lg font-mono tabular-nums font-medium text-earth-900">
                  {formatCurrency(steadyIncome)}
                </div>
              </div>
              <div>
                <div className="text-xs text-earth-500">Monthly Outflow</div>
                <div className="text-lg font-mono tabular-nums font-medium text-earth-900">
                  {formatCurrency(totalOutflows)}
                </div>
              </div>
            </div>
          </section>

          {/* Income vs Transitional Pool + 3-Bucket Expenses */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-5 space-y-6">
              <section className="bg-white border border-earth-200 rounded-xl p-6 space-y-4">
                <div>
                  <h3 className="text-base font-semibold text-earth-900">
                    1. Steady Monthly Money
                  </h3>
                  <p className="text-xs text-earth-500 mt-0.5">
                    Only count reliable recurring income you can plan rent and groceries around.
                  </p>
                </div>

                <div className="space-y-3">
                  <NumberRow
                    label="Take-Home Paycheck (Monthly)"
                    value={budget.netPaycheck}
                    onChange={(v) => updateIncome('netPaycheck', v)}
                  />
                  <NumberRow
                    label="Reliable Support (Child / Spousal)"
                    value={budget.reliableSupport}
                    onChange={(v) => updateIncome('reliableSupport', v)}
                  />
                  <NumberRow
                    label="Other Steady Income"
                    value={budget.otherSteadyIncome}
                    onChange={(v) => updateIncome('otherSteadyIncome', v)}
                  />
                </div>
              </section>

              <section className="bg-white border border-earth-200 rounded-xl p-6 space-y-4">
                <div>
                  <h3 className="text-base font-semibold text-earth-900">
                    2. Transitional Pool (One-Time Cash)
                  </h3>
                  <p className="text-xs text-earth-500 mt-0.5">
                    Keep lump-sum savings and settlements separate so they are not mistaken for monthly income.
                  </p>
                </div>

                <div className="space-y-3">
                  <NumberRow
                    label="Solo Cash Currently Available"
                    value={budget.soloCashAvailable}
                    onChange={(v) => updateIncome('soloCashAvailable', v)}
                  />
                  <NumberRow
                    label="Expected Settlement / Cash Split"
                    value={budget.expectedSettlementCash}
                    onChange={(v) => updateIncome('expectedSettlementCash', v)}
                  />
                </div>

                {/* Peace-of-Mind Cushion Milestones */}
                <div className="pt-4 border-t border-earth-100 space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-earth-800">
                      Peace-of-Mind Cushion Progress
                    </span>
                    <span className="font-mono tabular-nums text-sage-800">
                      {cushionPctOfSixMonths}% of 6-mo goal
                    </span>
                  </div>
                  <div className="w-full h-2 bg-earth-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-sage-700 rounded-full transition-all"
                      style={{ width: `${cushionPctOfSixMonths}%` }}
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                    <div>
                      <div className="text-earth-500">1-Mo Target</div>
                      <div className="font-mono tabular-nums font-medium text-earth-900">
                        {formatCurrency(oneMonthTarget)}
                      </div>
                    </div>
                    <div>
                      <div className="text-earth-500">3-Mo Target</div>
                      <div className="font-mono tabular-nums font-medium text-earth-900">
                        {formatCurrency(threeMonthTarget)}
                      </div>
                    </div>
                    <div>
                      <div className="text-earth-500">6-Mo Target</div>
                      <div className="font-mono tabular-nums font-medium text-earth-900">
                        {formatCurrency(sixMonthTarget)}
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {/* 3-Bucket Monthly Outflows */}
            <div className="lg:col-span-7 bg-white border border-earth-200 rounded-xl p-6 space-y-6">
              <div>
                <h3 className="text-base font-semibold text-earth-900">
                  3. Simple Monthly Outflows
                </h3>
                <p className="text-xs text-earth-500 mt-0.5">
                  Grouped into two calm buckets instead of 25 micro-categories.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-earth-100">
                    <span className="text-xs font-semibold text-earth-800">
                      Bucket A · Must-Pays
                    </span>
                    <span className="text-xs font-mono tabular-nums font-medium text-earth-900">
                      {formatCurrency(mustPaysTotal)}/mo
                    </span>
                  </div>
                  <NumberRow
                    label="Rent or Mortgage"
                    value={budget.mustPays.housing}
                    onChange={(v) => updateMustPay('housing', v)}
                  />
                  <NumberRow
                    label="Utilities & Internet"
                    value={budget.mustPays.utilities}
                    onChange={(v) => updateMustPay('utilities', v)}
                  />
                  <NumberRow
                    label="Groceries & Household"
                    value={budget.mustPays.groceries}
                    onChange={(v) => updateMustPay('groceries', v)}
                  />
                  <NumberRow
                    label="Childcare / After-School"
                    value={budget.mustPays.childcare}
                    onChange={(v) => updateMustPay('childcare', v)}
                  />
                  <NumberRow
                    label="Minimum Debt Payments"
                    value={budget.mustPays.minimumDebt}
                    onChange={(v) => updateMustPay('minimumDebt', v)}
                  />
                  <NumberRow
                    label="Health & Auto Insurance"
                    value={budget.mustPays.insurance}
                    onChange={(v) => updateMustPay('insurance', v)}
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-earth-100">
                    <span className="text-xs font-semibold text-earth-800">
                      Bucket B · Life &amp; Kids
                    </span>
                    <span className="text-xs font-mono tabular-nums font-medium text-earth-900">
                      {formatCurrency(lifeAndKidsTotal)}/mo
                    </span>
                  </div>
                  <NumberRow
                    label="School & Kid Activities"
                    value={budget.lifeAndKids.schoolAndActivities}
                    onChange={(v) => updateLifeKids('schoolAndActivities', v)}
                  />
                  <NumberRow
                    label="Medical Co-Pays"
                    value={budget.lifeAndKids.medicalCopays}
                    onChange={(v) => updateLifeKids('medicalCopays', v)}
                  />
                  <NumberRow
                    label="Gas, Transit & Car Upkeep"
                    value={budget.lifeAndKids.transportation}
                    onChange={(v) => updateLifeKids('transportation', v)}
                  />
                  <NumberRow
                    label="Personal Essentials"
                    value={budget.lifeAndKids.personalEssentials}
                    onChange={(v) => updateLifeKids('personalEssentials', v)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Housing Comparison Sandbox */}
          <section className="bg-white border border-earth-200 rounded-xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-earth-100 pb-4">
              <div>
                <h2 className="text-xl font-semibold text-earth-900">
                  Housing Decision: Keep the House vs. Rent / Downsize
                </h2>
                <p className="text-xs text-earth-500 mt-1">
                  Uses your steady monthly income ({formatCurrency(steadyIncome)}/mo) and non-housing expenses ({formatCurrency(nonHousingExpenses)}/mo).
                </p>
              </div>
              <div className="text-xs font-medium text-sage-800 whitespace-nowrap">
                {monthlyDifference >= 0
                  ? `Downsizing frees ${formatCurrency(monthlyDifference)}/mo`
                  : `Keeping saves ${formatCurrency(Math.abs(monthlyDifference))}/mo`}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Option 1: Keep Current Home */}
              <div className="border border-earth-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-earth-900">
                    Option A: Keep Marital Home
                  </h3>
                  <span className="text-xs font-mono tabular-nums text-earth-500">
                    {formatCurrency(keepTotalHousing)}/mo total
                  </span>
                </div>

                <SliderControl
                  label="Refinanced / Assumed Mortgage"
                  value={keepMortgage}
                  min={800}
                  max={4500}
                  step={50}
                  onChange={setKeepMortgage}
                />
                <SliderControl
                  label="Property Tax & Homeowners Insurance"
                  value={keepTaxIns}
                  min={150}
                  max={1200}
                  step={25}
                  onChange={setKeepTaxIns}
                />
                <SliderControl
                  label="Monthly Repair & Maintenance Reserve"
                  value={keepUpkeep}
                  min={0}
                  max={800}
                  step={25}
                  onChange={setKeepUpkeep}
                />

                <div className="pt-4 border-t border-earth-100 flex items-center justify-between">
                  <span className="text-xs text-earth-600">Monthly Cash Left Over</span>
                  <span
                    className={`text-lg font-mono tabular-nums font-medium ${
                      keepLeftover >= 0 ? 'text-earth-900' : 'text-red-800'
                    }`}
                  >
                    {formatCurrency(keepLeftover)}/mo
                  </span>
                </div>
              </div>

              {/* Option 2: Rent or Downsize */}
              <div className="border border-earth-200 rounded-xl p-5 space-y-4 bg-earth-50/70">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-semibold text-earth-900">
                    Option B: Rent or Downsize
                  </h3>
                  <span className="text-xs font-mono tabular-nums text-earth-500">
                    {formatCurrency(rentTotalHousing)}/mo total
                  </span>
                </div>

                <SliderControl
                  label="Monthly Rent / Smaller Mortgage"
                  value={rentAmount}
                  min={800}
                  max={4000}
                  step={50}
                  onChange={setRentAmount}
                />
                <SliderControl
                  label="Utility Change vs. Current Home"
                  value={rentUtilitiesDelta}
                  min={-250}
                  max={250}
                  step={10}
                  onChange={setRentUtilitiesDelta}
                  signed
                />

                <div className="pt-4 border-t border-earth-200/70 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-earth-600">Monthly Cash Left Over</span>
                    <span
                      className={`text-lg font-mono tabular-nums font-medium ${
                        rentLeftover >= 0 ? 'text-sage-700' : 'text-red-800'
                      }`}
                    >
                      {formatCurrency(rentLeftover)}/mo
                    </span>
                  </div>
                  <p className="text-xs text-earth-600 leading-relaxed">
                    {rentLeftover > keepLeftover
                      ? `Renting or downsizing leaves an extra ${formatCurrency(
                          rentLeftover - keepLeftover
                        )}/month—adding ${formatCurrency(
                          (rentLeftover - keepLeftover) * 12
                        )} a year to your personal cushion.`
                      : `At these numbers, keeping the home costs ${formatCurrency(
                          keepLeftover - rentLeftover
                        )}/month less than moving, provided upkeep stays predictable.`}
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Work & Childcare Net Gain */}
          <section className="bg-white border border-earth-200 rounded-xl p-6 space-y-5">
            <div>
              <h2 className="text-xl font-semibold text-earth-900">
                Work &amp; Childcare Net-Gain Check
              </h2>
              <p className="text-xs text-earth-500 mt-1">
                Evaluating a new job or extra hours? See what actually lands in your pocket after taxes and childcare.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <SliderControl
                label="Gross Monthly Pay"
                value={grossMonthlyPay}
                min={1500}
                max={12000}
                step={100}
                onChange={setGrossMonthlyPay}
              />
              <SliderControl
                label="Estimated Tax Withholding (%)"
                value={taxRatePct}
                min={10}
                max={35}
                step={1}
                onChange={setTaxRatePct}
                isPercent
              />
              <SliderControl
                label="Monthly Childcare Cost"
                value={monthlyChildcare}
                min={0}
                max={3000}
                step={50}
                onChange={setMonthlyChildcare}
              />
            </div>

            <div className="pt-4 border-t border-earth-100 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div>
                <div className="text-xs text-earth-500">Estimated Taxes</div>
                <div className="font-mono tabular-nums font-medium text-earth-900 mt-0.5">
                  -{formatCurrency(estimatedTaxes)}/mo
                </div>
              </div>
              <div>
                <div className="text-xs text-earth-500">Childcare Cost</div>
                <div className="font-mono tabular-nums font-medium text-earth-900 mt-0.5">
                  -{formatCurrency(monthlyChildcare)}/mo
                </div>
              </div>
              <div>
                <div className="text-xs text-earth-500">True Monthly Take-Home Gain</div>
                <div
                  className={`text-lg font-mono tabular-nums font-semibold mt-0.5 ${
                    trueNetFromWork >= 0 ? 'text-sage-700' : 'text-red-800'
                  }`}
                >
                  {formatCurrency(trueNetFromWork)}/mo
                </div>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

function NumberRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (val: number) => void;
}) {
  return (
    <label className="flex items-center justify-between gap-3 text-xs text-earth-700">
      <span className="flex-1">{label}</span>
      <div className="relative w-28 shrink-0">
        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-earth-400 font-mono">
          $
        </span>
        <input
          type="number"
          min={0}
          value={value}
          onChange={(e) => onChange(Number(e.target.value) || 0)}
          className="w-full pl-6 pr-2 py-1.5 text-right font-mono tabular-nums text-xs text-earth-900 border border-earth-200 rounded-md focus:outline-none focus:ring-2 focus:ring-sage-700"
        />
      </div>
    </label>
  );
}

function SliderControl({
  label,
  value,
  min,
  max,
  step,
  onChange,
  isPercent,
  signed,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (val: number) => void;
  isPercent?: boolean;
  signed?: boolean;
}) {
  const displayValue = isPercent
    ? `${value}%`
    : signed && value > 0
    ? `+${formatCurrency(value)}`
    : formatCurrency(value);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="text-earth-700">{label}</span>
        <span className="font-mono tabular-nums font-medium text-earth-900">
          {displayValue}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-sage-700 cursor-pointer"
      />
    </div>
  );
}
