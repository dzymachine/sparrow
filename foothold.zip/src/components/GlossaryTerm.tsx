import { useEffect, useRef, useState } from 'react';
import { GLOSSARY } from '../data/initialData';

interface GlossaryTermProps {
  termKey: keyof typeof GLOSSARY;
  label?: string;
}

export function GlossaryTerm({ termKey, label }: GlossaryTermProps) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLSpanElement>(null);
  const entry = GLOSSARY[termKey];

  useEffect(() => {
    if (!open) return;
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleKey);
    };
  }, [open]);

  if (!entry) return <span>{label ?? termKey}</span>;

  return (
    <span ref={containerRef} className="relative inline-block">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="underline decoration-dotted decoration-sage-700/70 underline-offset-4 text-earth-900 font-medium hover:text-sage-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sage-700 rounded-sm cursor-pointer"
        aria-expanded={open}
      >
        {label ?? termKey}
      </button>
      {open && (
        <span
          role="dialog"
          aria-label={entry.term}
          className="absolute left-0 top-full mt-2 z-40 w-72 sm:w-80 bg-white border border-earth-200 rounded-lg p-4 shadow-lg text-left"
        >
          <span className="block text-xs font-semibold text-sage-800 mb-1">
            Plain-English Guide
          </span>
          <span className="block text-sm font-semibold text-earth-900 mb-1.5">
            {entry.term}
          </span>
          <span className="block text-xs leading-relaxed text-earth-600">
            {entry.summary}
          </span>
        </span>
      )}
    </span>
  );
}
