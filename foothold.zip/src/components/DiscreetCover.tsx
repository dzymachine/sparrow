import { CloudSun, Wind, Droplets } from 'lucide-react';

interface DiscreetCoverProps {
  onReturn: () => void;
}

export function DiscreetCover({ onReturn }: DiscreetCoverProps) {
  return (
    <div className="min-h-screen bg-earth-50 text-earth-900 flex flex-col">
      <header className="bg-white border-b border-earth-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-8">
          <span className="text-lg font-semibold tracking-tight text-earth-900 whitespace-nowrap shrink-0">
            Daily Almanac &amp; Weather
          </span>
          <nav className="hidden sm:flex items-center gap-6 text-sm text-earth-600">
            <span className="whitespace-nowrap shrink-0">Local Forecast</span>
            <span className="whitespace-nowrap shrink-0">Weekly Recipes</span>
            <span className="whitespace-nowrap shrink-0">Gardening Notes</span>
          </nav>
          <button
            type="button"
            onClick={onReturn}
            className="text-xs font-medium text-earth-600 hover:text-earth-900 px-3 py-2 rounded-md border border-earth-200 bg-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Return to Workspace
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-6 py-10 space-y-8">
        <section className="bg-white border border-earth-200 rounded-xl p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div>
              <p className="text-xs text-earth-500 mb-1">Regional Outlook · Updated Today</p>
              <h1 className="text-3xl font-semibold text-earth-900">Mild &amp; Partly Cloudy</h1>
              <p className="text-sm text-earth-600 mt-2 max-w-xl">
                Pleasant afternoon breeze with clear skies expected toward evening. Good conditions for outdoor errands and garden prep.
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <CloudSun className="w-12 h-12 text-amber-600" aria-hidden="true" />
              <div className="text-right">
                <div className="text-3xl font-mono tabular-nums font-medium text-earth-900">64°F</div>
                <div className="text-xs text-earth-500">High 67° / Low 49°</div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-earth-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center gap-2 text-earth-600">
              <Wind className="w-4 h-4 text-earth-400" aria-hidden="true" />
              <span>Wind 8 mph NW</span>
            </div>
            <div className="flex items-center gap-2 text-earth-600">
              <Droplets className="w-4 h-4 text-earth-400" aria-hidden="true" />
              <span>Humidity 48%</span>
            </div>
            <div className="text-earth-600">UV Index: Moderate (4)</div>
            <div className="text-earth-600">Sunset: 5:18 PM</div>
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <article className="bg-white border border-earth-200 rounded-xl p-6">
            <p className="text-xs text-earth-500 mb-1">Kitchen Notes · 25 min prep</p>
            <h2 className="text-xl font-semibold text-earth-900 mb-2">
              Simple Roasted Butternut &amp; Herb Soup
            </h2>
            <p className="text-sm text-earth-600 leading-relaxed">
              Toss cubed squash, yellow onion, and garlic with olive oil and thyme. Roast at 400°F until golden, then simmer briefly with vegetable broth and blend smooth.
            </p>
          </article>

          <article className="bg-white border border-earth-200 rounded-xl p-6">
            <p className="text-xs text-earth-500 mb-1">Seasonal Checklist · November</p>
            <h2 className="text-xl font-semibold text-earth-900 mb-2">
              Autumn Porch &amp; Planter Prep
            </h2>
            <p className="text-sm text-earth-600 leading-relaxed">
              Trim back spent perennials, clear gutters before early rains, and bring tender terracotta pots into a sheltered garage before the first frost.
            </p>
          </article>
        </section>
      </main>
    </div>
  );
}
