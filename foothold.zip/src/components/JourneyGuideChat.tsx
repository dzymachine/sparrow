import { useEffect, useRef, useState } from 'react';
import {
  MessageSquare,
  X,
  Send,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';
import { AppState, NavSection } from '../types';
import { STAGE_META } from '../data/initialData';

interface SuggestedNav {
  section: NavSection;
  label: string;
  reason: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  suggestedNav?: SuggestedNav[];
}

interface JourneyGuideChatProps {
  state: AppState;
  activeTab: NavSection;
  isOpen: boolean;
  onToggleOpen: (open: boolean) => void;
  onNavigate: (tab: NavSection) => void;
}

const STARTER_PROMPTS = [
  'Where should I start right now?',
  'I do not know all our account balances yet',
  'How do I test if I can afford the house?',
  'Where do I track shared kid expenses?',
];

export function JourneyGuideChat({
  state,
  activeTab,
  isOpen,
  onToggleOpen,
  onNavigate,
}: JourneyGuideChatProps) {
  const stageMeta = STAGE_META[state.stage];

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `You are currently in ${stageMeta.number} (${stageMeta.label}). Ask me any money question in plain English, or tell me what feels most overwhelming today and I will point you to the right tool here.`,
      suggestedNav: [
        {
          section: 'roadmap',
          label: 'View Step-by-Step Roadmap',
          reason: 'See your active tasks and copy-paste scripts.',
        },
      ],
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isLoading]);

  const steadyIncome =
    state.budget.netPaycheck +
    state.budget.reliableSupport +
    state.budget.otherSteadyIncome;
  const totalOutflows =
    Object.values(state.budget.mustPays).reduce((a, b) => a + b, 0) +
    Object.values(state.budget.lifeAndKids).reduce((a, b) => a + b, 0);
  const breathingRoom = steadyIncome - totalOutflows;

  const sendPrompt = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed || isLoading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: trimmed,
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput('');
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const response = await fetch('/api/guide-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: nextHistory
            .filter((m) => m.id !== 'welcome')
            .map((m) => ({ role: m.role, text: m.text })),
          context: {
            stage: state.stage,
            stageLabel: stageMeta.label,
            activeTab,
            comfortLevel: state.comfortLevel,
            doneTasks: state.tasks.filter((t) => t.status === 'done').length,
            totalTasks: state.tasks.length,
            unknownAccounts: state.accounts.filter(
              (a) => a.status === 'unknown' || a.balance === null
            ).length,
            sharedAccounts: state.accounts.filter((a) => a.status === 'shared').length,
            breathingRoom,
          },
        }),
      });

      const data = (await response.json()) as {
        reply?: string;
        suggestedNav?: SuggestedNav[];
        error?: string;
      };

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Could not reach the Journey Guide.');
      }

      const modelMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        role: 'model',
        text: data.reply || 'Let us take this one step at a time.',
        suggestedNav: data.suggestedNav ?? [],
      };
      setMessages((prev) => [...prev, modelMsg]);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Something went wrong. Please try again.';
      setErrorMsg(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendPrompt(input);
  };

  const handleResetChat = () => {
    setErrorMsg(null);
    setMessages([
      {
        id: 'welcome',
        role: 'model',
        text: `You are currently in ${stageMeta.number} (${stageMeta.label}). Ask me any money question in plain English, or tell me what feels most overwhelming today and I will point you to the right tool here.`,
        suggestedNav: [
          {
            section: 'overview',
            label: 'Go to Where I Stand',
            reason: 'Review your Next 3 Moves.',
          },
        ],
      },
    ]);
  };

  return (
    <>
      {!isOpen && (
        <button
          type="button"
          onClick={() => onToggleOpen(true)}
          className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-sage-700 hover:bg-sage-800 rounded-xl shadow-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          aria-label="Open Foothold Journey Guide"
        >
          <MessageSquare className="w-4 h-4" aria-hidden="true" />
          Journey Guide
        </button>
      )}

      {isOpen && (
        <aside
          aria-label="Foothold Journey Guide"
          className="fixed bottom-4 right-4 z-50 w-[calc(100vw-2rem)] sm:w-[410px] h-[580px] max-h-[calc(100vh-2rem)] bg-white border border-earth-200 rounded-xl shadow-2xl flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-4 py-3.5 bg-earth-50 border-b border-earth-200 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-sm font-semibold text-earth-900 truncate">
                Foothold Journey Guide
              </div>
              <div className="text-xs text-earth-500 truncate">
                {stageMeta.number} · {stageMeta.label}
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={handleResetChat}
                aria-label="Reset conversation"
                title="Start fresh conversation"
                className="p-1.5 text-earth-500 hover:text-earth-900 rounded-md hover:bg-earth-200/60 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => onToggleOpen(false)}
                aria-label="Close Journey Guide"
                className="p-1.5 text-earth-500 hover:text-earth-900 rounded-md hover:bg-earth-200/60 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-earth-50/40">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[90%] rounded-xl px-3.5 py-2.5 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === 'user'
                      ? 'bg-sage-700 text-white'
                      : 'bg-white border border-earth-200 text-earth-800'
                  }`}
                >
                  {msg.text}
                </div>

                {msg.role === 'model' &&
                  msg.suggestedNav &&
                  msg.suggestedNav.length > 0 && (
                    <div className="mt-2 w-[90%] space-y-1.5">
                      {msg.suggestedNav.map((nav, idx) => (
                        <button
                          key={`${msg.id}-nav-${idx}`}
                          type="button"
                          onClick={() => onNavigate(nav.section)}
                          className="w-full text-left px-3 py-2 rounded-lg border border-sage-200 bg-sage-50 hover:bg-sage-100 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-semibold text-sage-800 truncate">
                              {nav.label}
                            </div>
                            <div className="text-[11px] text-earth-600 truncate">
                              {nav.reason}
                            </div>
                          </div>
                          <ArrowRight
                            className="w-3.5 h-3.5 text-sage-700 shrink-0"
                            aria-hidden="true"
                          />
                        </button>
                      ))}
                    </div>
                  )}
              </div>
            ))}

            {isLoading && (
              <div className="flex items-start">
                <div className="bg-white border border-earth-200 rounded-xl px-3.5 py-2.5 text-xs text-earth-500">
                  Thinking through your next step...
                </div>
              </div>
            )}

            {errorMsg && (
              <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-xs text-red-800">
                {errorMsg}
              </div>
            )}

            {messages.length === 1 && !isLoading && (
              <div className="pt-1 space-y-1.5">
                <div className="text-[11px] font-medium text-earth-500">
                  Common starting questions
                </div>
                <div className="flex flex-col gap-1.5">
                  {STARTER_PROMPTS.map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => void sendPrompt(q)}
                      className="text-left px-3 py-2 text-xs text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-100/70 transition-colors cursor-pointer"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div ref={endRef} />
          </div>

          {/* Input */}
          <form
            onSubmit={handleSubmit}
            className="p-3 bg-white border-t border-earth-200 flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question or where to go..."
              disabled={isLoading}
              className="flex-1 min-w-0 px-3 py-2 text-xs sm:text-sm text-earth-900 border border-earth-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sage-700 disabled:bg-earth-50"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              aria-label="Send message"
              className="p-2 text-white bg-sage-700 hover:bg-sage-800 disabled:bg-earth-300 rounded-lg transition-colors shrink-0 cursor-pointer"
            >
              <Send className="w-4 h-4" aria-hidden="true" />
            </button>
          </form>
        </aside>
      )}
    </>
  );
}
