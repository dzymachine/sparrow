import { ArrowRight, CheckCircle2, Clock, Circle, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { AppState, NavSection, RoadmapTask, TaskStatus } from '../types';
import { STAGE_META } from '../data/initialData';
import { formatCurrency } from '../utils/format';
import { GlossaryTerm } from './GlossaryTerm';

interface OverviewViewProps {
  state: AppState;
  onNavigate: (tab: NavSection) => void;
  onUpdateTaskStatus: (taskId: string, status: TaskStatus) => void;
  onOpenIntake: () => void;
  onOpenGuide: () => void;
}

export function OverviewView({
  state,
  onNavigate,
  onUpdateTaskStatus,
  onOpenIntake,
  onOpenGuide,
}: OverviewViewProps) {
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const stageMeta = STAGE_META[state.stage];

  // Financial summary calculations
  const steadyIncome =
    state.budget.netPaycheck +
    state.budget.reliableSupport +
    state.budget.otherSteadyIncome;

  const mustPaysTotal = Object.values(state.budget.mustPays).reduce((a, b) => a + b, 0);
  const lifeAndKidsTotal = Object.values(state.budget.lifeAndKids).reduce(
    (a, b) => a + b,
    0
  );
  const totalEssentials = mustPaysTotal + lifeAndKidsTotal;
  const breathingRoom = steadyIncome - totalEssentials;

  const soloCount = state.accounts.filter((a) => a.status === 'solo').length;
  const totalAccounts = state.accounts.length;
  const unknownCount = state.accounts.filter((a) => a.status === 'unknown').length;

  // Next 3 Moves: prioritize active (todo/waiting) tasks in current stage, then upcoming stages
  const stageOrder = ['considering', 'preparing', 'separating', 'finalizing', 'rebuilding'];
  const currentIdx = stageOrder.indexOf(state.stage);

  const activeTasks = state.tasks
    .filter((t) => t.status !== 'done')
    .sort((a, b) => {
      const aStageIdx = stageOrder.indexOf(a.stage);
      const bStageIdx = stageOrder.indexOf(b.stage);
      const aDist = aStageIdx >= currentIdx ? aStageIdx - currentIdx : aStageIdx + 10;
      const bDist = bStageIdx >= currentIdx ? bStageIdx - currentIdx : bStageIdx + 10;
      if (aDist !== bDist) return aDist - bDist;
      return a.priorityOrder - b.priorityOrder;
    });

  const nextThree = activeTasks.slice(0, 3);
  const completedCount = state.tasks.filter((t) => t.status === 'done').length;

  const handleCopyScript = async (task: RoadmapTask) => {
    if (!task.scriptBody) return;
    try {
      await navigator.clipboard.writeText(task.scriptBody);
      setCopiedId(task.id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Fallback ignored if clipboard restricted
    }
  };

  return (
    <div className="space-y-8">
      {/* Calm Hero Stage Header */}
      <section className="bg-white border border-earth-200 rounded-xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="text-xs font-medium text-sage-800">
              {stageMeta.number} · {stageMeta.label} · {completedCount} of {state.tasks.length} steps completed
            </div>
            <h1 className="text-2xl sm:text-3xl font-semibold text-earth-900 leading-tight">
              {stageMeta.headline}
            </h1>
            <p className="text-sm text-earth-600 leading-relaxed">
              {stageMeta.reassurance}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenIntake}
              className="px-4 py-2 text-sm font-medium text-earth-700 bg-white border border-earth-200 rounded-lg hover:bg-earth-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Update My Stage
            </button>
            <button
              type="button"
              onClick={() => onNavigate('clarity')}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Test What-If Scenarios
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </section>

      {/* 4-Column Financial Snapshot */}
      <section aria-label="Financial baseline summary" className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white border border-earth-200 rounded-xl p-5">
          <div className="text-xs text-earth-500">Steady Monthly Baseline</div>
          <div className="mt-2 text-2xl font-mono tabular-nums font-medium text-earth-900">
            {formatCurrency(steadyIncome)}
          </div>
          <div className="mt-1.5 text-xs text-earth-500">
            Paycheck &amp; reliable support only
          </div>
        </div>

        <div className="bg-white border border-earth-200 rounded-xl p-5">
          <div className="text-xs text-earth-500">Monthly Essentials</div>
          <div className="mt-2 text-2xl font-mono tabular-nums font-medium text-earth-900">
            {formatCurrency(totalEssentials)}
          </div>
          <div className="mt-1.5 text-xs text-earth-500">
            Must-pays + kids &amp; daily life
          </div>
        </div>

        <div className="bg-white border border-earth-200 rounded-xl p-5">
          <div className="text-xs text-earth-500">
            {breathingRoom >= 0 ? 'Monthly Breathing Room' : 'Monthly Cash Gap'}
          </div>
          <div
            className={`mt-2 text-2xl font-mono tabular-nums font-medium ${
              breathingRoom >= 0 ? 'text-sage-700' : 'text-amber-800'
            }`}
          >
            {formatCurrency(breathingRoom)}
          </div>
          <div className="mt-1.5 text-xs text-earth-500">
            {breathingRoom >= 0
              ? 'Available for cushion & solo goals'
              : 'Covered by transitional savings'}
          </div>
        </div>

        <div className="bg-white border border-earth-200 rounded-xl p-5">
          <div className="text-xs text-earth-500">Accounts Untangled</div>
          <div className="mt-2 text-2xl font-mono tabular-nums font-medium text-earth-900">
            {soloCount} / {totalAccounts}
          </div>
          <div className="mt-1.5 text-xs text-earth-500">
            {unknownCount > 0
              ? `${unknownCount} unknown balance to verify`
              : 'All balances documented'}
          </div>
        </div>
      </section>

      {/* Main Split: Next 3 Moves + Plain-English Guide */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Next 3 Moves (2 columns) */}
        <section className="lg:col-span-2 bg-white border border-earth-200 rounded-xl">
          <div className="px-6 py-4 border-b border-earth-200 flex items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold text-earth-900">Your Next 3 Moves</h2>
              <p className="text-xs text-earth-500 mt-0.5">
                Focused strictly on your current phase so you never feel behind.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('roadmap')}
              className="text-xs font-medium text-sage-800 hover:text-sage-900 underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer"
            >
              View Full Roadmap
            </button>
          </div>

          {nextThree.length === 0 ? (
            <div className="p-8 text-center space-y-3">
              <CheckCircle2 className="w-8 h-8 text-sage-700 mx-auto" aria-hidden="true" />
              <h3 className="text-base font-semibold text-earth-900">
                Every roadmap step is complete
              </h3>
              <p className="text-sm text-earth-600 max-w-md mx-auto">
                You have worked through your entire checklist. Visit the full roadmap to add personal next steps anytime.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('roadmap')}
                className="px-4 py-2 text-sm font-medium text-white bg-sage-700 rounded-lg hover:bg-sage-800 transition-colors cursor-pointer"
              >
                Open Roadmap
              </button>
            </div>
          ) : (
            <div className="divide-y divide-earth-200">
              {nextThree.map((task, idx) => {
                const isExpanded = expandedTaskId === task.id;
                const meta = STAGE_META[task.stage];
                return (
                  <div key={task.id} className="p-6">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="space-y-1.5 flex-1">
                        <div className="text-xs text-earth-500">
                          Move 0{idx + 1} · {meta.shortLabel} · {task.duration}
                          {task.status === 'waiting' && ' · Waiting on someone else'}
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedTaskId(isExpanded ? null : task.id)
                          }
                          className="text-left text-base font-semibold text-earth-900 hover:text-sage-800 transition-colors cursor-pointer"
                        >
                          {task.title}
                        </button>
                        <p className="text-sm text-earth-600 leading-relaxed">
                          {task.whyItMatters}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateTaskStatus(
                              task.id,
                              task.status === 'waiting' ? 'todo' : 'waiting'
                            )
                          }
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                            task.status === 'waiting'
                              ? 'bg-amber-50 border-amber-200 text-amber-800'
                              : 'bg-white border-earth-200 text-earth-600 hover:bg-earth-50'
                          }`}
                        >
                          <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                          {task.status === 'waiting' ? 'Waiting' : 'Mark Waiting'}
                        </button>

                        <button
                          type="button"
                          onClick={() => onUpdateTaskStatus(task.id, 'done')}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-sage-700 text-white hover:bg-sage-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          <Circle className="w-3.5 h-3.5" aria-hidden="true" />
                          Mark Done
                        </button>
                      </div>
                    </div>

                    <div className="mt-3">
                      <button
                        type="button"
                        onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                        className="text-xs font-medium text-sage-800 hover:text-sage-900 cursor-pointer"
                      >
                        {isExpanded ? 'Hide exact steps' : 'Show exact steps & script'}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="mt-4 pt-4 border-t border-earth-100 space-y-4">
                        <ol className="space-y-2 text-sm text-earth-700 list-decimal list-inside">
                          {task.steps.map((stepText, sIdx) => (
                            <li key={sIdx} className="leading-relaxed">
                              {stepText}
                            </li>
                          ))}
                        </ol>

                        {task.scriptBody && (
                          <div className="bg-earth-50 border border-earth-200 rounded-lg p-4 space-y-2">
                            <div className="flex items-center justify-between gap-4">
                              <span className="text-xs font-semibold text-earth-800">
                                {task.scriptTitle ?? 'Copy-Paste Script'}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleCopyScript(task)}
                                className="inline-flex items-center gap-1.5 text-xs font-medium text-sage-800 hover:text-sage-900 cursor-pointer"
                              >
                                {copiedId === task.id ? (
                                  <>
                                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                                    Copied
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                                    Copy Script
                                  </>
                                )}
                              </button>
                            </div>
                            <pre className="text-xs text-earth-700 whitespace-pre-wrap font-sans leading-relaxed">
                              {task.scriptBody}
                            </pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Right Rail: Plain-English Money Decoder & Quick Links */}
        <aside className="space-y-6">
          <div className="bg-white border border-earth-200 rounded-xl p-6 space-y-4">
            <div>
              <p className="text-xs text-earth-500">Jargon-Free Guide · Click any term</p>
              <h2 className="text-lg font-semibold text-earth-900 mt-0.5">
                Terms You Might Hear Soon
              </h2>
            </div>
            <p className="text-sm text-earth-600 leading-relaxed">
              Attorneys and banks use confusing shorthand. Tap any dotted term below for a plain-English explanation:
            </p>
            <ul className="space-y-2.5 text-sm text-earth-700 pt-1">
              <li>
                • Splitting a 401(k) requires a <GlossaryTerm termKey="QDRO" />.
              </li>
              <li>
                • Upfront legal deposits are called a <GlossaryTerm termKey="Retainer" />.
              </li>
              <li>
                • Post-divorce tax status may shift to{' '}
                <GlossaryTerm termKey="Head of Household" />.
              </li>
              <li>
                • Protecting your credit starts with a{' '}
                <GlossaryTerm termKey="Credit Freeze" />.
              </li>
              <li>
                • Updating a <GlossaryTerm termKey="Beneficiary" /> overrides a will.
              </li>
            </ul>
          </div>

          <div className="bg-white border border-earth-200 rounded-xl p-6 space-y-3">
            <h3 className="text-base font-semibold text-earth-900">
              Private Safety Reminder
            </h3>
            <p className="text-xs text-earth-600 leading-relaxed">
              Every figure you enter stays in your browser session. We do not force bank account logins, so linking accounts will never send an unexpected verification code to a shared email or phone.
            </p>
            <div className="pt-2 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={onOpenGuide}
                className="px-3 py-1.5 text-xs font-medium text-white bg-sage-700 hover:bg-sage-800 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Ask Journey Guide
              </button>
              <button
                type="button"
                onClick={() => onNavigate('vault')}
                className="px-3 py-1.5 text-xs font-medium text-earth-700 bg-earth-100 hover:bg-earth-200 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Open Account Vault
              </button>
              <button
                type="button"
                onClick={() => onNavigate('protection')}
                className="px-3 py-1.5 text-xs font-medium text-earth-700 bg-earth-100 hover:bg-earth-200 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Co-Parenting Ledger
              </button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
