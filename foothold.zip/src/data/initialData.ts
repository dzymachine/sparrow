import { AppState, JourneyStage } from '../types';

export const STAGE_META: Record<
  JourneyStage,
  {
    number: string;
    label: string;
    shortLabel: string;
    headline: string;
    reassurance: string;
  }
> = {
  considering: {
    number: 'Phase 01',
    label: 'Quiet Contemplation',
    shortLabel: '1. Contemplating',
    headline: 'Explore what solo life could cost, privately and without pressure.',
    reassurance:
      'You do not need to link any bank accounts or make decisions today. Start with rough numbers and clear facts.',
  },
  preparing: {
    number: 'Phase 02',
    label: 'Quiet Preparation',
    shortLabel: '2. Quiet Prep',
    headline: 'Get visibility into household accounts before anything changes.',
    reassurance:
      'Focus on gathering copies of key documents, checking your own credit, and establishing a private solo account.',
  },
  separating: {
    number: 'Phase 03',
    label: 'Active Separation',
    shortLabel: '3. Separating',
    headline: 'Keep day-to-day cash steady while testing settlement tradeoffs.',
    reassurance:
      'Separate temporary transition costs from your long-term monthly baseline so you can evaluate proposals clearly.',
  },
  finalizing: {
    number: 'Phase 04',
    label: 'Finalizing & Untangling',
    shortLabel: '4. Untangling',
    headline: 'Work through joint accounts, QDROs, and beneficiary updates step by step.',
    reassurance:
      'Take these administrative steps one at a time. Mark items as waiting whenever the ball is in someone else’s court.',
  },
  rebuilding: {
    number: 'Phase 05',
    label: 'Solo Stabilization',
    shortLabel: '5. Rebuilding',
    headline: 'Build your solo peace-of-mind cushion and grow on your own terms.',
    reassurance:
      'Your baseline is yours. Focus on steady monthly breathing room and simple, automated savings.',
  },
};

export const GLOSSARY: Record<string, { term: string; summary: string }> = {
  QDRO: {
    term: 'QDRO (Qualified Domestic Relations Order)',
    summary:
      'A separate court order required to divide a 401(k) or pension without triggering taxes or early-withdrawal penalties. A divorce decree alone is usually not enough—make sure it gets filed.',
  },
  Retainer: {
    term: 'Legal Retainer',
    summary:
      'An upfront deposit paid to an attorney or mediator that they draw from as they work on your case. Ask for itemized monthly invoices so you know how quickly it is being used.',
  },
  'Head of Household': {
    term: 'Head of Household (Tax Filing)',
    summary:
      'A tax filing status for unmarried individuals who pay more than half the cost of keeping up a home for a qualifying child. It generally offers a lower tax rate and larger standard deduction than filing Single.',
  },
  Beneficiary: {
    term: 'Beneficiary Designation',
    summary:
      'The person named directly on a 401(k), IRA, or life insurance policy to receive funds. Beneficiary forms override what is written in a will, so updating them after divorce is essential.',
  },
  Escrow: {
    term: 'Mortgage Escrow',
    summary:
      'An account held by your mortgage lender where part of your monthly payment goes to cover property taxes and homeowners insurance automatically.',
  },
  'Credit Freeze': {
    term: 'Credit Freeze',
    summary:
      'A free lock placed at Equifax, Experian, and TransUnion that stops anyone (including an ex-partner) from opening new credit cards or loans in your name without your permission.',
  },
};

export const INITIAL_STATE: AppState = {
  stage: 'preparing',
  comfortLevel: 'beginner',
  urgentFocus: ['Untangle joint accounts', 'See what I can afford'],
  tasks: [
    {
      id: 't-1',
      stage: 'considering',
      title: 'Run a private "What would solo life cost?" estimate',
      duration: '10 min',
      whyItMatters:
        'Vague fear about money keeps many women stuck. Putting rough numbers on housing, groceries, and income turns anxiety into a concrete plan.',
      steps: [
        'Open the Clarity & Sandbox tab in this workspace.',
        'Enter your current take-home pay (or realistic target pay).',
        'Adjust the Housing slider to compare local 2-bedroom rent vs. your current mortgage.',
      ],
      status: 'done',
      priorityOrder: 1,
    },
    {
      id: 't-2',
      stage: 'considering',
      title: 'Create a private email address for financial & legal steps',
      duration: '10 min',
      whyItMatters:
        'Shared family computers, tablets, or synced inboxes can expose sensitive bank alerts or attorney emails prematurely.',
      steps: [
        'Set up a brand-new email address with a strong, unique password.',
        'Turn on two-factor authentication tied only to your personal phone.',
        'Use this email for solo bank accounts, credit reports, and legal inquiries.',
      ],
      status: 'done',
      priorityOrder: 2,
    },
    {
      id: 't-3',
      stage: 'preparing',
      title: 'Open a solo checking account at a separate bank',
      duration: '20 min',
      whyItMatters:
        'Having an account solely in your name at a bank your spouse does not use protects your emergency cash and gives you a clean place to route your paycheck.',
      steps: [
        'Choose an FDIC-insured bank or credit union with no shared history.',
        'Apply online using your new private email and solo mailing address (or PO box if needed).',
        'Move a small initial cushion and update your direct deposit when ready.',
      ],
      scriptTitle: 'HR Direct Deposit Switch Email',
      scriptBody:
        'Hi [HR/Payroll Name],\n\nPlease update my payroll direct deposit instructions starting with the next pay cycle. Attached is my voided check / routing details for my new individual account.\n\nThank you,\n[Your Name]',
      status: 'todo',
      priorityOrder: 1,
    },
    {
      id: 't-4',
      stage: 'preparing',
      title: 'Pull your free credit report to spot unknown joint debts',
      duration: '15 min',
      whyItMatters:
        'Credit cards, auto loans, or lines of credit opened during marriage can show up on your credit report even if your spouse managed them.',
      steps: [
        'Visit AnnualCreditReport.com (the official federally authorized site).',
        'Download reports from Equifax, Experian, and TransUnion as PDFs.',
        'Add any unfamiliar accounts to the Account Vault marked "Unknown / Needs Discovery."',
      ],
      status: 'todo',
      priorityOrder: 2,
    },
    {
      id: 't-5',
      stage: 'preparing',
      title: 'Save copies of 12 months of statements & 3 years of tax returns',
      duration: '30 min',
      whyItMatters:
        'Once separation begins, online logins sometimes get changed. Having PDFs upfront saves thousands in attorney discovery fees later.',
      steps: [
        'Download the last 3 federal & state tax returns (Form 1040 + W-2s/1099s).',
        'Save PDFs of checking, savings, mortgage, and retirement account balances.',
        'Store them in a private cloud folder only you can access.',
      ],
      status: 'waiting',
      priorityOrder: 3,
    },
    {
      id: 't-6',
      stage: 'separating',
      title: 'Test "Keep the House vs. Downsize" before signing anything',
      duration: '15 min',
      whyItMatters:
        'Keeping the marital home feels emotionally safe, but mortgage, taxes, and repairs can leave you cash-poor. Test the 5-year math first.',
      steps: [
        'Go to Clarity & Sandbox -> Decision Sandbox.',
        'Input your estimated post-divorce mortgage + property tax + 1% yearly upkeep.',
        'Compare your monthly leftover cash against renting a smaller home.',
      ],
      status: 'todo',
      priorityOrder: 1,
    },
    {
      id: 't-7',
      stage: 'separating',
      title: 'Track legal retainer & transition expenses separately from monthly bills',
      duration: '10 min',
      whyItMatters:
        'Mixing one-time legal retainers with groceries and rent makes your monthly budget look unsustainable when it is actually just a temporary spike.',
      steps: [
        'Enter your current solo cash and expected legal/moving costs in the Transitional Pool.',
        'Keep your Steady Monthly Baseline focused strictly on recurring living costs.',
      ],
      status: 'todo',
      priorityOrder: 2,
    },
    {
      id: 't-8',
      stage: 'finalizing',
      title: 'Confirm QDRO filing for any shared 401(k) or pension split',
      duration: '20 min',
      whyItMatters:
        'Even if your divorce decree awards you half of a retirement account, the plan administrator cannot transfer it without a signed QDRO.',
      steps: [
        'Ask your attorney or QDRO specialist if the draft order was sent to the plan administrator for pre-approval.',
        'Track the transfer status in your Account Vault until funds land in your own IRA.',
      ],
      scriptTitle: 'Email to Attorney About QDRO Status',
      scriptBody:
        'Hi [Attorney Name],\n\nNow that our decree is finalized, could you confirm who is drafting the QDRO for [Spouse’s Employer 401(k)] and the expected timeline for plan pre-approval and court filing?\n\nBest,\n[Your Name]',
      status: 'todo',
      priorityOrder: 1,
    },
    {
      id: 't-9',
      stage: 'finalizing',
      title: 'Call auto & health insurers to establish solo coverage',
      duration: '25 min',
      whyItMatters:
        'You cannot stay on an ex-spouse’s employer health plan after finalization, and auto policies must match who owns and drives each car.',
      steps: [
        'Compare COBRA vs. your employer plan vs. ACA Marketplace (divorce is a Qualifying Life Event with a 60-day window).',
        'Call your auto insurer to split policies and confirm solo title/registration.',
      ],
      scriptTitle: 'Phone Script: Splitting Auto Insurance',
      scriptBody:
        '"Hi, I recently separated/divorced and need to move my vehicle onto an individual policy in my name only. Can you quote a solo policy effective [Date] and confirm my prior continuous coverage discount carries over?"',
      status: 'todo',
      priorityOrder: 2,
    },
    {
      id: 't-10',
      stage: 'finalizing',
      title: 'Complete Beneficiary & Estate Reset across all accounts',
      duration: '20 min',
      whyItMatters:
        'An outdated beneficiary form can override your will. Update 401(k)s, IRAs, life insurance, and payable-on-death bank accounts.',
      steps: [
        'Open the Protection & Ledger tab and go through the Beneficiary Reset list.',
        'Log into each provider and designate new primary/contingent beneficiaries.',
      ],
      status: 'todo',
      priorityOrder: 3,
    },
    {
      id: 't-11',
      stage: 'rebuilding',
      title: 'Build your first 1-month Peace-of-Mind Cushion',
      duration: '15 min',
      whyItMatters:
        'One full month of essential expenses sitting in your solo savings breaks the paycheck-to-paycheck stress cycle.',
      steps: [
        'Set up an automatic transfer—even $50 or $100 per paycheck—into a high-yield solo savings account.',
        'Track your 1-month, 3-month, and 6-month progress in the Clarity tab.',
      ],
      status: 'todo',
      priorityOrder: 1,
    },
    {
      id: 't-12',
      stage: 'rebuilding',
      title: 'Restart retirement contributions in your own name',
      duration: '20 min',
      whyItMatters:
        'Even small regular contributions into a 401(k) or Roth IRA rebuild long-term independence and capture employer matching.',
      steps: [
        'Check if your employer offers a 401(k) match and contribute at least enough to get the full match.',
        'If not offered, consider opening a low-cost Roth IRA with an automated target-date or index fund.',
      ],
      status: 'todo',
      priorityOrder: 2,
    },
  ],
  accounts: [
    {
      id: 'a-1',
      name: 'Joint Household Checking',
      institution: 'Chase Bank',
      type: 'Checking',
      balance: 6420,
      isDebt: false,
      status: 'shared',
      checks: {
        myNameOnly: false,
        exRemoved: false,
        autopayMoved: false,
        passwordUpdated: false,
      },
      notes: 'Used for mortgage and utilities; still shared during separation.',
    },
    {
      id: 'a-2',
      name: 'My New Solo Checking',
      institution: 'Ally Bank',
      type: 'Checking',
      balance: 3150,
      isDebt: false,
      status: 'solo',
      checks: {
        myNameOnly: true,
        exRemoved: true,
        autopayMoved: true,
        passwordUpdated: true,
      },
      notes: 'Opened privately with new email. Routing personal paycheck here next month.',
    },
    {
      id: 'a-3',
      name: 'Joint Rewards Visa',
      institution: 'Capital One',
      type: 'Credit Card',
      balance: 2840,
      isDebt: true,
      status: 'in_progress',
      checks: {
        myNameOnly: false,
        exRemoved: false,
        autopayMoved: true,
        passwordUpdated: false,
      },
      notes: 'Switched personal streaming/groceries off this card; waiting to pay down and close.',
    },
    {
      id: 'a-4',
      name: 'Marital Home Mortgage',
      institution: 'Wells Fargo Home',
      type: 'Mortgage / Lease',
      balance: 294000,
      isDebt: true,
      status: 'shared',
      checks: {
        myNameOnly: false,
        exRemoved: false,
        autopayMoved: false,
        passwordUpdated: false,
      },
      notes: 'Evaluating whether to refinance/keep or sell in the Housing Sandbox.',
    },
    {
      id: 'a-5',
      name: 'Spouse Employer 401(k)',
      institution: 'Fidelity',
      type: 'Retirement',
      balance: null,
      isDebt: false,
      status: 'unknown',
      checks: {
        myNameOnly: false,
        exRemoved: false,
        autopayMoved: false,
        passwordUpdated: false,
      },
      notes: 'Do not have login access. Added to attorney financial disclosure request.',
    },
    {
      id: 'a-6',
      name: 'My Personal 403(b)',
      institution: 'Vanguard',
      type: 'Retirement',
      balance: 48200,
      isDebt: false,
      status: 'solo',
      checks: {
        myNameOnly: true,
        exRemoved: true,
        autopayMoved: true,
        passwordUpdated: true,
      },
      notes: 'Need to update beneficiary once decree is finalized.',
    },
    {
      id: 'a-7',
      name: 'Family Auto Insurance',
      institution: 'GEICO',
      type: 'Insurance',
      balance: 215,
      isDebt: false,
      status: 'in_progress',
      checks: {
        myNameOnly: false,
        exRemoved: false,
        autopayMoved: false,
        passwordUpdated: true,
      },
      notes: 'Requested solo quote for my SUV; waiting on effective date.',
    },
  ],
  budget: {
    netPaycheck: 4450,
    reliableSupport: 750,
    otherSteadyIncome: 0,
    soloCashAvailable: 9500,
    expectedSettlementCash: 18000,
    mustPays: {
      housing: 1950,
      utilities: 260,
      groceries: 620,
      childcare: 540,
      minimumDebt: 180,
      insurance: 240,
    },
    lifeAndKids: {
      schoolAndActivities: 220,
      medicalCopays: 120,
      transportation: 280,
      personalEssentials: 240,
    },
    cushionGoalMonthly: 350,
  },
  splitExpenses: [
    {
      id: 'e-1',
      date: '2026-11-02',
      description: 'Pediatric dental co-pay & fluoride treatment',
      category: 'Medical',
      totalAmount: 140,
      mySharePercent: 50,
      paidByMe: true,
      status: 'requested',
      note: 'Receipt saved; emailed summary on Nov 3.',
    },
    {
      id: 'e-2',
      date: '2026-11-06',
      description: 'Winter soccer league registration',
      category: 'Activities',
      totalAmount: 180,
      mySharePercent: 50,
      paidByMe: true,
      status: 'logged',
      note: 'Agreed via text before sign-up.',
    },
    {
      id: 'e-3',
      date: '2026-10-21',
      description: 'After-school care (October)',
      category: 'Childcare',
      totalAmount: 420,
      mySharePercent: 50,
      paidByMe: true,
      status: 'reimbursed',
      note: 'Reimbursed $210 via Zelle.',
    },
    {
      id: 'e-4',
      date: '2026-11-09',
      description: 'School field trip & winter coat',
      category: 'School',
      totalAmount: 95,
      mySharePercent: 50,
      paidByMe: true,
      status: 'logged',
      note: 'Needs to be added to end-of-month request.',
    },
  ],
  beneficiaries: [
    {
      id: 'b-1',
      accountName: 'My 403(b) Retirement Plan (Vanguard)',
      category: 'Retirement',
      currentStatus: 'needs_update',
      guidance:
        'Check whether spousal consent is required before finalization; update immediately once decree is signed.',
    },
    {
      id: 'b-2',
      accountName: 'Employer Term Life Insurance',
      category: 'Insurance',
      currentStatus: 'in_progress',
      guidance:
        'If naming minor children, ask an estate attorney about setting up a simple trust or UTMA custodian instead of naming a minor directly.',
    },
    {
      id: 'b-3',
      accountName: 'Solo Checking & High-Yield Savings (Ally)',
      category: 'Banking',
      currentStatus: 'updated',
      guidance: 'Payable-on-Death (POD) designation added for trusted family member.',
    },
    {
      id: 'b-4',
      accountName: 'Healthcare Proxy & Power of Attorney',
      category: 'Legal & Estate',
      currentStatus: 'needs_update',
      guidance:
        'Revoke prior spouse designations and name a trusted parent, sibling, or close friend for medical and financial emergencies.',
    },
    {
      id: 'b-5',
      accountName: 'Health Insurance Coverage Transition',
      category: 'Insurance',
      currentStatus: 'in_progress',
      guidance:
        'Divorce triggers a 60-day Special Enrollment window—compare your employer plan, ACA Marketplace, and COBRA before the deadline.',
    },
  ],
};
